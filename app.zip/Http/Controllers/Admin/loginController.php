<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        $email = $request->input('login_email');
        $password = $request->input('login_password');

        // Check user from DB
        $admin = DB::table('admin')->where('email', $email)->first();

        if ($admin) {
            if (Hash::check($password, $admin->password)) {
                // Set session
                session(['admin_session' => 'Yes']);

                return redirect('admin/index'); 
            } else {
                return redirect()->back()->with('error', 'Invalid password');
            }
        } else {
            return redirect()->back()->with('error', 'Invalid email');
        }
    }

    public function view(){
      return view('admin.login');
    }

   public function logout()
{
    session()->forget('admin_session');
    return redirect('/admin/login')->with('success', 'Logged out successfully');
}




}
