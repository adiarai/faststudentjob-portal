<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class indexController extends Controller
{
    public function view(){

         $totalJobTypes = DB::table('job_types')->count();
    $totalCities = DB::table('job_city')->count();
    $totalApplications = DB::table('applications')->count();
        return view('admin.index', compact('totalJobTypes', 'totalCities','totalApplications'));
    }
}
