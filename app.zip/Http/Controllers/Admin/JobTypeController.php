<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class JobTypeController extends Controller
{
    // View Form
    public function view()
    {
        return view('admin.new-job-type');
    }
 
    // Insert Job Type
    public function store(Request $request)
    {
        $request->validate([
            'type_name' => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        $slug = $this->generateUniqueSlug($request->input('type_name'));

        DB::table('job_types')->insert([
            'type_name' => $request->input('type_name'),
            'slug' => $slug,
            'content' => $request->input('content'),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect()->back()->with('success', 'Job type inserted successfully!');
    }

    // Show All Job Types
    public function show()
    {
        $data = DB::table('job_types')->get();
        return view('admin.show-job-type', compact('data'));
    }

    // Delete Job Type
    public function delete($del_id)
    {
        DB::table('job_types')->where('id', $del_id)->delete();
        return redirect()->route('admin.job-type.view');
    }

    // Slug Generator
    private function createSlug($string)
    {
        $slug = strtolower($string);
        $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
        $slug = preg_replace('/[\s-]+/', '-', $slug);
        return trim($slug, '-');
    }

    private function generateUniqueSlug($title, $table = 'job_types', $column = 'slug')
    {
        $baseSlug = $this->createSlug($title);
        $slug = $baseSlug;
        $counter = 1;

        while (DB::table($table)->where($column, $slug)->exists()) {
            $slug = $baseSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }
}
