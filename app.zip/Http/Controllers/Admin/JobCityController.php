<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class JobCityController extends Controller
{
    
     public function view()
    {
        return view('admin.new-job-city');
    }

    public function store(Request $request)
    {
        $request->validate([
            'city_name' => 'required|string|max:255',
            'content' => 'required|string',
        ]);

        $slug = $this->generateUniqueSlug($request->input('city_name'));

        DB::table('job_city')->insert([
            'city_name' => $request->input('city_name'),
            'slug' => $slug,
            'content' => $request->input('content'),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return redirect()->back()->with('success', 'Job City inserted successfully!');
    }



       // Slug Generator
    private function createSlug($string)
    {
        $slug = strtolower($string);
        $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
        $slug = preg_replace('/[\s-]+/', '-', $slug);
        return trim($slug, '-');
    }

    private function generateUniqueSlug($title, $table = 'job_city', $column = 'slug')
    {
        $baseSlug = $this->createSlug($title);
        $slug = $baseSlug;
        $counter = 1;

        while (DB::table($table)->where($column, $slug)->exists()) {
            $slug = $baseSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }


        public function show()
    {
        $data = DB::table('job_city')->get();
        return view('admin.show-job-city', compact('data'));
    }

    // Delete Job Type
    public function delete($del_id)
    {
        DB::table('job_city')->where('id', $del_id)->delete();
        return redirect()->route('admin.job-city.view');
    }

}
