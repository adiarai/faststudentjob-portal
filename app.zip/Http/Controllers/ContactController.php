<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;


class ContactController extends Controller
{


  public function save(Request $request)
{
    $f_name = $request->f_name;
    $last_name = $request->last_name;
    $email = $request->email;
    $phone_no = $request->phone_no;
    $description = $request->description;

    $full_name = $f_name . ' ' . $last_name;

    $admin_email_body = '
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>New Contact Form Submission</title>
    </head>
    <body style="font-family: Arial, Helvetica, sans-serif; background:#f4f6f8; margin:0; padding:20px;">
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td align="center">
            <table width="680" cellpadding="0" cellspacing="0" role="presentation" style="max-width:680px; background:#ffffff; border-radius:8px; overflow:hidden; box-shadow:0 2px 6px rgba(0,0,0,0.1);">
              <tr style="background:#0d6efd; color:#ffffff;">
                <td style="padding:20px 24px;">
                  <h1 style="margin:0; font-size:20px;">New Contact Form Submission</h1>
                  <p style="margin:4px 0 0 0; font-size:13px; opacity:0.95;">Fast Student Jobs — Contact Enquiry</p>
                </td>
                <td style="padding:20px 24px; text-align:right;">
                  <small style="font-size:12px; color:rgba(255,255,255,0.9);">'.date('d M, Y').'</small>
                </td>
              </tr>
              <tr>
                <td colspan="2" style="padding:18px 24px; border-bottom:1px solid #eef2f6;">
                  <p style="margin:0 0 12px 0; font-size:14px; color:#333;">A new user has submitted the contact form. Details are below:</p>
                  <table width="100%" cellpadding="6" cellspacing="0" role="presentation" style="font-size:14px; color:#333;">
                    <tr>
                      <td width="160" style="vertical-align:top; font-weight:600; color:#555;">Name:</td>
                      <td style="vertical-align:top;">'.$full_name.'</td>
                    </tr>
                    <tr style="background:#fafafa;">
                      <td style="vertical-align:top; font-weight:600; color:#555;">Email:</td>
                      <td style="vertical-align:top;"><a href="mailto:'.$email.'" style="color:#0d6efd; text-decoration:none;">'.$email.'</a></td>
                    </tr>
                    <tr>
                      <td style="vertical-align:top; font-weight:600; color:#555;">Phone Number:</td>
                      <td style="vertical-align:top;">'.$phone_no.'</td>
                    </tr>
                    <tr style="background:#fafafa;">
                      <td style="vertical-align:top; font-weight:600; color:#555;">Message:</td>
                      <td style="vertical-align:top; line-height:1.5;">'.$description.'</td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr>
                <td colspan="2" style="padding:16px 24px; font-size:12px; color:#777;">
                  <p style="margin:0;">This email was generated automatically by Fast Student Jobs. Please respond to the user as appropriate.</p>
                </td>
              </tr>
              <tr style="background:#f8f9fb;">
                <td colspan="2" style="padding:12px 24px; font-size:12px; color:#999; text-align:center;">
                  &copy; Fast Student Jobs • Sent on '.date('d M, Y').'
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </body>
    </html>';

    $to_email = "info@faststudentjob.de";
    $subject = 'New Contact Form from ' . $full_name . ' - ' . date('d M Y h:i:s A');

    Mail::html($admin_email_body, function ($message) use ($to_email, $subject) {
        $message->to($to_email)
                ->subject($subject);
    });

return redirect()->route('contact.page')->with('success', 'Your message has been sent successfully!');
}
}
