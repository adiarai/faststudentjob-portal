<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class viewjobController extends Controller
{
    public function view_job_by_job_type($job_type_slug){
        $data=DB::table('job_types')->where('slug', $job_type_slug)->first();
        return view('job-by-type',compact('data'));
    }

    public function view_job_by_job_city($job_city_slug){
        $data=DB::table('job_city')->where('slug', $job_city_slug)->first();
        return view('job-by-city',compact('data'));
    }

    
    public function main_cities_view(){
        $all_city_data=DB::table('job_city')->orderBy('city_name', 'asc')->get();
        return view('cities',compact('all_city_data'));
    }

     public function main_job_types_view(){
        $all_job_types_data=DB::table('job_types')->orderBy('type_name', 'asc')->get();
        return view('job-types',compact('all_job_types_data'));
    }

    
}
