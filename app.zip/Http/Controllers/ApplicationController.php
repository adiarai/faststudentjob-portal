<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;


class ApplicationController extends Controller
{
    public function store(Request $request)
    {
        // Validate inputs
        $request->validate([
            'full_name' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'job_type' => 'required|string|max:255',
            'whatsapp' => 'required|string|max:20|unique:applications,whatsapp',
            'email' => 'required|email|max:255|unique:applications',
            'description' => 'nullable|string',
            'cv' => 'required|mimes:pdf,doc,docx|max:2048'
        ]);

        // Handle CV upload
        $cvName = time() . '_' . $request->file('cv')->getClientOriginalName();
        $request->file('cv')->move(public_path('uploads/cv'), $cvName);

        // Save to database

        $reference=rand(9999,100000);

        DB::table('applications')->insert([
            'full_name' => $request->full_name,
            'city' => $request->city,
            'job_type' => $request->job_type,
            'whatsapp' => $request->whatsapp,
            'email' => $request->email,
            'description' => $request->description,
            'cv_path' => 'uploads/cv/' . $cvName,
            'reference'=>$reference,
            'created_at' => now(),
            'updated_at' => now(),
        ]); 

        $applicant_name=$request->full_name;
        $applicant_email=$request->email;

        $user_email_body = '
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>New Contact Form Submission</title>
    </head>
    <body style="font-family: Arial, Helvetica, sans-serif; background:#f4f6f8; margin:0; padding:20px;">
      <table width="100%" cellpadding="0" cellspacing="0" role="presentation">
        <tr>
          <td align="center">
            <table width="680" cellpadding="0" cellspacing="0" role="presentation" style="max-width:680px; background:#ffffff; border-radius:8px; overflow:hidden; box-shadow:0 2px 6px rgba(0,0,0,0.1);">
              <tr style="background:green; color:#ffffff;">
                <td style="padding:20px 24px;">
                  <h1 style="margin:0; font-size:20px;">Application Submitted Successfully</h1>
                  <p style="margin:4px 0 0 0; font-size:13px; opacity:0.95;">Fast Student Jobs — Application Enquiry</p>
                </td>
                <td style="padding:20px 24px; text-align:right;">
                  <small style="font-size:12px; color:rgba(255,255,255,0.9);">'.date('d M, Y').'</small>
                </td>
              </tr>
              <tr>
                <td colspan="2" style="padding:18px 24px; border-bottom:1px solid #eef2f6;">
                  <h2 style="margin:0 0 12px 0; font-size:20px; color:#333;">Congratulations!</h2>
                  <p style="color:green">Hi '.$applicant_name.', your application has been submitted successfully</p>

                    <p style="font-size:18px; line-height:1.6;">
                        Thank you for applying with us.  
                        Your Reference Number is:  
                        <strong style="font-size:22px; color:#FB8500;">'.$reference.'</strong>
                    </p>
                
                </td>
              </tr>
              <tr>
                <td colspan="2" style="padding:16px 24px; font-size:12px; color:#777;">
                  <p style="margin:0;">This email was generated automatically by Fast Student Jobs. Please respond to the user as appropriate.</p>
                </td>
              </tr>
              <tr style="background:#f8f9fb;">
                <td colspan="2" style="padding:12px 24px; font-size:12px; color:#999; text-align:center;">
                  &copy; Fast Student Jobs • Sent on '.date('d M, Y').'
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </body>
    </html>';

    $subject = 'Application Submitted Successfully ' . $applicant_name . ' - ' . date('d M Y h:i:s A');

    Mail::html($user_email_body, function ($message) use ($applicant_email, $subject) {
        $message->to($applicant_email)
                ->subject($subject);
    });

         return redirect()->route('application.successfull', ['ref_no' => $reference]);
    }

    public function viewadimfile(){
         $data = DB::table('applications')->get();
        return view('admin.applications', compact('data'));
    }

      // Delete Job Type
    public function delete($del_id)
    {
        DB::table('applications')->where('id', $del_id)->delete();
        return redirect()->route('admin.applications');
    }



    public function congrats($ref_no){

    $check = DB::table('applications')->where('reference',$ref_no)->first();
    if($check){

        return view('congrats',compact('ref_no'));

    }
    else{
        return redirect()->route('index.page');
    }

    }

    

public function trackingsubmit(Request $request)
{
    $detail = DB::table('applications')->where('reference', $request->ref_no)->first();

    if ($detail) {
        return view('tracking-data', compact('detail'));
    } else {
        return redirect()->route('track.application')->with('error', 'Invalid reference number.');
    }
}
 


public function updateview(Request $request)
{
    $detail = DB::table('applications')->where('id', $request->update_id)->first();

    if ($detail) {
        return view('admin.applications-update', compact('detail'));

    } else {
        // return redirect()->route('admin.dashboard')->with('error', 'Invalid reference number.');
    }
}




 public function updatesubmit(Request $request)
    {
        // Validate inputs
        $request->validate([
            'full_name' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'job_type' => 'required|string|max:255',
            'whatsapp' => 'required|string|max:20',
            'email' => 'required|email|max:255',
            'description' => 'nullable|string',
            'status' => 'required',
            'ref_no' => 'required',
        ]);



        DB::table('applications')->where('reference',$request->ref_no)->update([
            'full_name' => $request->full_name,
            'city' => $request->city,
            'job_type' => $request->job_type,
            'whatsapp' => $request->whatsapp,
            'email' => $request->email,
            'description' => $request->description,
            'status' => $request->status,
            'admin_notes' => $request->admin_notes,
            'updated_at' => now(),
        ]);

         return redirect()->route('admin.applications');
    }


}