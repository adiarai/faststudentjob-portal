<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class SubscriberController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'email' => 'required|email'
        ]);

        $email = $request->email;
        $ip = $request->ip();

        // Check if already exists
        $exists = DB::table('subscribers')
            ->where('email', $email)
            ->where('ip', $ip)
            ->exists();

        if ($exists) {
            return response()->json([
                'status' => 'error',
                'message' => 'You have already subscribed with this email and IP.'
            ]);
        }

        // Insert new subscriber
        DB::table('subscribers')->insert([
            'email' => $email,
            'ip' => $ip,
            'subscribed_at' => Carbon::now(),
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'You have successfully subscribed!'
        ]);
    }
}
