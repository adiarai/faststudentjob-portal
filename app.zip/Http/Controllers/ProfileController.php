<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class ProfileController extends Controller
{
    public function fileview(){
        $data=DB::table('admin')->first();
        return view('admin.profile', compact('data'));
    }

    public function update_email(Request $request){
       
        DB::table('admin')->where('id',1)->update([
            'email' => $request->email
        ]);

         return redirect()->route('admin.profile')->with('success','Record updated');
    }


    public function update_password(Request $request)
{
    $request->validate([
        'cur_password' => 'required',
        'new_password' => 'required|min:6',
        'confirm_password' => 'required|same:new_password',
    ]);

    $curadmin = DB::table('admin')->where('id', 1)->first();

    // 1. Check current password
    if (!Hash::check($request->cur_password, $curadmin->password)) {
        return redirect()->back()->with('error', 'Invalid current password');
    }

    // 2. Hash new password
    $save = Hash::make($request->new_password);

    // 3. Update in DB
    DB::table('admin')->where('id', 1)->update(['password' => $save]);

    return redirect()->route('admin.profile')->with('success', 'Password updated successfully');
}

}
