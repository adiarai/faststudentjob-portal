<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\loginController;
use App\Http\Controllers\Admin\indexController;
use App\Http\Controllers\Admin\JobTypeController;
use App\Http\Controllers\Admin\JobCityController;

use App\Http\Controllers\viewjobController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\SubscriberController;
use App\Http\Controllers\ApplicationController;
use App\Http\Controllers\ProfileController;





Route::get('/', function () {
    return view('index');
})->name('index.page');

Route::get('index', function () {
    return view('index');
})->name('index.page');


Route::get('about', function () {
    return view('about');
})->name('about.page');




Route::get('job-types/{job_type_slug}', [viewjobController::class, 'view_job_by_job_type']);
Route::get('jobs/{job_city_slug}', [viewjobController::class, 'view_job_by_job_city']);

Route::get('/cities', [viewjobController::class, 'main_cities_view'])->name('page.city');
Route::get('/job-types', [viewjobController::class, 'main_job_types_view'])->name('page.job.types');



Route::get('contact', function () {
    return view('contact');
})->name('contact.page');


Route::post('/contact-submit', [ContactController::class, 'save'])->name('submit.contact');

Route::post('/subscribe', [SubscriberController::class, 'store'])->name('subscribe.store');


Route::post('/apply', [ApplicationController::class, 'store'])->name('application.store');

Route::get('/applied-successfully/{ref_no}', [ApplicationController::class, 'congrats'])
    ->name('application.successfull');


Route::post('/applied-tracking', [ApplicationController::class, 'trackingsubmit'])
    ->name('application.track');

    

Route::get('track-application', function () {
    return view('tracking');
})->name('track.application');



Route::get('pricing', function () {
    return view('pricing');
})->name('pricing.page');

Route::get('privacy-policy', function () {
    return view('privacy-policy');
})->name('privacy-policy.page');


Route::get('term-conditions', function () {
    return view('term-conditions');
})->name('term-condititon.page');

Route::get('refund-policy', function () {
    return view('refund-policy');
})->name('refund-policy.page');


Route::get('faqs', function () {
    return view('faqs');
})->name('faqs.page');


Route::get('testimonials', function () {
    return view('testimonials');
})->name('testimonials.page');



Route::get('apply-now', function () {
    return view('apply-now');
})->name('apply-now.page');



Route::get('admin/login', [loginController::class, 'view']);
Route::post('admin/login_submit', [loginController::class, 'login']);


Route::middleware(['admin.auth'])->group(function () {

Route::get('admin/index', [indexController::class, 'view'])->name('admin.dashboard');
Route::get('admin/new-job-type', [JobTypeController::class, 'view'])->name('admin.new-job-type');
Route::post('admin/new-job-type/store', [JobTypeController::class, 'store'])->name('job-type.store');
Route::get('admin/view-job-type', [JobTypeController::class, 'show'])->name('admin.job-type.view');
Route::get('admin/delete-job-type/{del_id}', [JobTypeController::class, 'delete'])->name('admin.job-type.delete');



Route::get('admin/new-job-city', [JobCityController::class, 'view'])->name('admin.new-job-city');
Route::post('admin/new-job-city/store', [JobCityController::class, 'store'])->name('job-city.store');
Route::get('admin/view-job-city', [JobCityController::class, 'show'])->name('admin.job-city.view');
Route::get('admin/delete-job-city/{del_id}', [JobCityController::class, 'delete'])->name('admin.job-city.delete');

Route::get('/search-cities', [JobCityController::class, 'search'])->name('search.cities');

Route::get('admin/Logout', [loginController::class, 'logout'])->name('admin.logout');

Route::get('admin/application', [ApplicationController::class, 'viewadimfile'])->name('admin.applications');

Route::get('admin/application/{del_id}', [ApplicationController::class, 'delete'])->name('admin.application.delete');


Route::get('admin/application/update/{update_id}', [ApplicationController::class, 'updateview'])->name('admin.application.update');

Route::post('admin/application/updatesubmit', [ApplicationController::class, 'updatesubmit'])->name('update-application');

Route::get('admin/profile', [ProfileController::class, 'fileview'])->name('admin.profile');
Route::post('admin/profile/email', [ProfileController::class, 'update_email'])->name('profile-email-update');

Route::post('admin/profile/password', [ProfileController::class, 'update_password'])->name('profile-password-update');


});

