@extends('layout')
<!--===== MOBILE HEADER STARTS =======-->
@section('main-content')
<style>
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }
</style>
<!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Contact Us</h1>
                    <div class="space20"></div>
                    <a href="index">Home <i class="fa-solid fa-angle-right"></i> <span>Contact Us</span></a>
                </div>
@if(session('success'))
    <div style="background: #d4edda; color: #155724; padding: 10px; border:1px solid #c3e6cb; border-radius: 4px; margin-bottom: 15px;">
        {{ session('success') }}
    </div>
@endif

            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="{{ asset('web-assets/img/all-images/hero/hero-img11.png')}}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== HERO AREA ENDS =======-->

<!--===== TESTIMONIAL AREA STARTS =======-->
<div class="contact-inner-area sp1">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="single-box">
                <div class="icons">
                    <svg xmlns="http://www.w3.org/2000/svg" width="33" height="32" viewBox="0 0 33 32" fill="none">
                    <path d="M5.83333 24.0013L12.5 16.0013M27.1667 24.0013L20.5 16.0013M4.5 10.668L14.1333 17.0901C14.9887 17.6604 15.4163 17.9456 15.8785 18.0562C16.2871 18.1542 16.7129 18.1542 17.1215 18.0562C17.5837 17.9456 18.0113 17.6604 18.8667 17.0901L28.5 10.668M8.76667 25.3346H24.2333C25.7268 25.3346 26.4736 25.3346 27.044 25.044C27.5457 24.7884 27.9537 24.3804 28.2093 23.8786C28.5 23.3082 28.5 22.5614 28.5 21.068V10.9346C28.5 9.44117 28.5 8.69442 28.2093 8.124C27.9537 7.62222 27.5457 7.21428 27.044 6.95862C26.4736 6.66797 25.7268 6.66797 24.2333 6.66797H8.76667C7.2732 6.66797 6.52645 6.66797 5.95603 6.95862C5.45425 7.21428 5.04631 7.62222 4.79065 8.124C4.5 8.69442 4.5 9.44116 4.5 10.9346V21.068C4.5 22.5614 4.5 23.3082 4.79065 23.8786C5.04631 24.3804 5.45425 24.7884 5.95603 25.044C6.52645 25.3346 7.27319 25.3346 8.76667 25.3346Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                </div>
                <div class="text">
                    <h4>Our Email</h4>
                    <div class="space14"></div>
                    <a href="mailto:info@faststudentjob.de">info@faststudentjob.de</a>
                </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="single-box">
                <div class="icons">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                <path d="M18.7333 7.9974C20.0357 8.25149 21.2325 8.88841 22.1708 9.82665C23.1091 10.7649 23.746 11.9617 24 13.2641M18.7333 2.66406C21.4391 2.96465 23.9621 4.17629 25.8884 6.10008C27.8145 8.02385 29.0295 10.5454 29.3333 13.2507M24.6667 27.9974C13.2528 27.9974 4 18.7446 4 7.33073C4 6.81577 4.01884 6.30521 4.05585 5.7997C4.09833 5.21956 4.11957 4.92949 4.2716 4.66544C4.39752 4.44674 4.62067 4.23934 4.84797 4.12973C5.12241 3.9974 5.44251 3.9974 6.08268 3.9974H9.83909C10.3774 3.9974 10.6466 3.9974 10.8774 4.086C11.0812 4.16426 11.2627 4.29138 11.4059 4.4562C11.568 4.64277 11.66 4.89574 11.844 5.40168L13.3988 9.67746C13.6128 10.2661 13.7199 10.5604 13.7017 10.8397C13.6857 11.0859 13.6016 11.3228 13.4589 11.5241C13.2971 11.7524 13.0286 11.9136 12.4915 12.2358L10.6667 13.3307C12.2692 16.8626 15.1335 19.7306 18.6667 21.3307L19.7616 19.5059C20.0839 18.9687 20.2449 18.7002 20.4732 18.5385C20.6745 18.3958 20.9115 18.3117 21.1577 18.2957C21.4369 18.2775 21.7313 18.3846 22.32 18.5986L26.5957 20.1534C27.1016 20.3374 27.3547 20.4294 27.5412 20.5915C27.706 20.7347 27.8332 20.9162 27.9113 21.1201C28 21.3507 28 21.6199 28 22.1583V25.9147C28 26.5549 28 26.875 27.8676 27.1494C27.758 27.3767 27.5507 27.5999 27.332 27.7258C27.0679 27.8778 26.7779 27.899 26.1977 27.9415C25.6921 27.9786 25.1816 27.9974 24.6667 27.9974Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                </div>
                <div class="text">
                    <h4>Call/Message</h4>
                    <div class="space14"></div>
                    <a href="https://www.wa.me/+4917685595503">+49 176 855 9550 3</a>
                </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <div class="single-box">
                <div class="icons">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32" fill="none">
                <path d="M16.0013 28C20.668 23.2 25.3346 18.9019 25.3346 13.6C25.3346 8.29807 21.156 4 16.0013 4C10.8466 4 6.66797 8.29807 6.66797 13.6C6.66797 18.9019 11.3346 23.2 16.0013 28Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M16 17.332C18.2092 17.332 20 15.5412 20 13.332C20 11.1229 18.2092 9.33203 16 9.33203C13.7908 9.33203 12 11.1229 12 13.332C12 15.5412 13.7908 17.332 16 17.332Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                </div>
                <div class="text">
                    <h4>our location</h4>
                    <div class="space14"></div>
                    <a href="#">Berlin, Germany (for official communication)</a>
                </div>
                </div>
            </div>
        </div>
        <div class="space70"></div>
        <div class="row align-items-center">
           <div class="col-lg-6">
    <div class="heading1">
        <h5 data-aos="zoom-in" data-aos-duration="900">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                <path d="M9.45001 17.8772C14.2115 17.6442 18 13.7338 18 8.94408C18 7.4743 17.6433 6.08732 17.0111 4.86399C14.4764 6.3183 13.2091 7.04546 12.2507 8.02546C11.1061 9.19582 10.2724 10.6308 9.82481 12.201C9.45001 13.5159 9.45001 14.9697 9.45001 17.8772Z" fill="#FB8500"/>
                <path d="M8.55001 17.8772C3.78851 17.6442 0 13.7338 0 8.94408C0 7.47429 0.356744 6.08731 0.988876 4.86398C3.52358 6.3183 4.79093 7.04546 5.74937 8.02547C6.89397 9.19583 7.72761 10.6308 8.17521 12.2011C8.55001 13.5159 8.55001 14.9697 8.55001 17.8772Z" fill="#FB8500"/>
                <path d="M1.43959 4.08981C3.97405 5.54399 5.24127 6.27107 6.57492 6.60594C8.16664 7.00559 9.83338 7.00559 11.4251 6.60594C12.7587 6.27108 14.026 5.54399 16.5604 4.08982C14.9571 1.62862 12.1699 0 9 0C5.8301 0 3.04295 1.62862 1.43959 4.08981Z" fill="#FB8500"/>
            </svg> Contact Us
        </h5>
        <div class="space16"></div>
        <h2 data-aos="zoom-in" data-aos-duration="1000">
            Let’s Connect and Build Your Future in Germany
        </h2>
        <div class="space16"></div>
        <p>
            At Fast Student Jobs, we help international students in Germany find part‑time jobs, internships and career opportunities. 
            Whether you need guidance or a job match, we are here for you.
        </p>
        <div class="space16"></div>
        <p>
            Contact us via phone or email – our team is ready to support you every step of the way and make your journey in Germany easier.
        </p>
        <div class="space32"></div>
        <ul class="contact-social">
            <li><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
            <li><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
            <li><a href="#"><i class="fa-brands fa-instagram"></i></a></li>
            <li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
        </ul>
    </div>
</div>


            <div class="col-lg-6">
                <div class="contact-main-boxarea" data-aos="fade-left" data-aos-duration="1200">
                    <h3>Send Massage</h3>
                    <div class="space16"></div>
                    <p>Our response time is within 30 minutes during business hours</p>
                    <div class="space16"></div>
                    <form action="{{ route('submit.contact') }}" method="post">
                        @csrf
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <input type="text" name="f_name" placeholder="First Name">
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <input type="text" name="last_name" placeholder="Last Name">
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <input type="email" name="email" placeholder="Email Address">
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <input type="number" name="phone_no" placeholder="Phone Number">
                            </div>
                        </div>

           

                        <div class="col-lg-12 col-md-12">
                            <div class="input-area">
                                <textarea name="description" placeholder="How can we help you?"></textarea>
                            </div>

                            @if(session('success'))
    <div style="background: #d4edda; color: #155724; padding: 10px; border:1px solid #c3e6cb; border-radius: 4px; margin-bottom: 15px;">
        {{ session('success') }}
    </div>
@endif
                        </div>

                        <div class="col-lg-12 col-md-12">
                            <div class="input-area text-end">
                                <button type="submit" name="submit" class="vl-btn1">Send Now <i class="fa-solid fa-arrow-right"></i></button>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
      
    </div>
</div>
<!--===== TESTIMONIAL AREA ENDS =======-->

<!--===== CTA AREA STARTS =======-->


@endsection