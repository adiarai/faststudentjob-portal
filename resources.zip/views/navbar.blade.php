
<style>
   .vl-offcanvas-social > a{
    padding-top: 15px
  }
</style>

<style>
  /* Import a nice web font (internal CSS) */
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500;700&display=swap');

  .site-logo {
    text-decoration: none;
    display: inline-block;
    padding: 2px 6px;
  }

  .logo-text {
    margin: 0;
    font-family: 'Poppins', system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
    font-weight: 700;
    font-size: 23px; /* adjust size as needed */
    letter-spacing:0px;
    line-height: 1;
    display: flex;
    gap: 0px; /* spacing between words */
    align-items: center;
  }

  /* Each word its own color */
  .logo-text .word {
    display: inline-block;
    transition: transform 0.18s ease, filter 0.18s ease;
    padding: 2px 2px;
    border-radius: 6px;
  }

  .logo-text .fast {
    color: #00B850; /* blue */
    /* background: rgba(15,107,255,0.06); */
  }

  .logo-text .student {
    color: black; /* orange */
    /* background: rgba(255,107,53,0.06); */
  }

  .logo-text .jobs {
    color: #00B850; /* green */
    /* background: rgba(34,197,94,0.06); */
  }

  /* Hover / focus effects */
  .site-logo:hover .word,
  .site-logo:focus .word {
    transform: translateY(-3px);
    filter: brightness(1.02);
  }

  /* Small screens adjust */
  @media (max-width: 480px) {
    .logo-text {
      font-size: 27px;
      gap: 2px;
    }
  }
</style>
{{-- <div class="preloader">
  <div class="loading-container">
    <div class="loading"></div>
    <div id="loading-icon">
      <!-- <img src="assets/img/logo/preloder.png" alt=""> -->
      <h3>Logo here</h3>
    </div>
  </div>
</div> --}}
<!--===== PRELOADER ENDS =======-->

<!--===== PROGRESS STARTS=======-->
<div class="paginacontainer">
     <div class="progress-wrap">
       <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
         <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98"/>
       </svg>
     </div>
   </div>
 <!--===== PROGRESS ENDS=======-->

<!--=====HEADER START=======-->
<header class="homepage1-body">
  <div id="vl-header-sticky" class="vl-header-area vl-transparent-header">
      <div class="container">
          <div class="row align-items-center row-bg1">
              <div class="col-lg-2 col-md-6 col-6">
                  <div class="vl-logo">
                      <a href="{{ route('index.page') }}" class="site-logo" aria-label="Home">
  <h3 class="logo-text">
    <span class="word fast">Fast</span>
    <span class="word student">Student </span>
    <span class="word jobs">Jobs </span>
  </h3>
</a>

                  </div>
              </div>
              <div class="col-lg-8 d-none d-lg-block">
                  <div class="vl-main-menu text-center">
                      <nav class="vl-mobile-menu-active">
                          <ul>
                              <li><a href="{{ route('index.page') }}">Home</a></li>

                              {{-- <li><a href="{{ route('about.page') }}">About Us</a></li> --}}

                              <li><a href="{{ route('page.city') }}">Job By City</a></li>
                              <li><a href="{{ route('page.job.types') }}">Job Types</a></li>


                              <li><a href="{{ route('contact.page') }}">Contact Us</a></li>
                              

                               <li class="has-dropdown">
                                <a href="#">Other Pages <span><i class="fa-solid fa-angle-down d-lg-inline d-none"></i></span></a>
                                  <ul class="sub-menu">
                                      <li><a href="{{ route('track.application') }}">Track Appications</a></li>

                                      <li><a href="{{ route('pricing.page') }}">Pricing & Payments</a></li>
                                      <li><a href="{{ route('privacy-policy.page') }}">Privacy Policy</a></li>
                                      <li><a href="{{ route('term-condititon.page') }}">Term & Conditions</a></li>
                                      <li><a href="{{ route('refund-policy.page') }}">Refund Policy</a></li>
                                      <li><a href="{{ route('faqs.page') }}">FAQ's</a></li>
                                      
                                  </ul>
                              </li>



                          </ul>
                      </nav>
                  </div>
              </div>
              <div class="col-lg-2 col-md-6 col-6">
                <div class="vl-hero-btn d-none d-lg-block text-end">
                  <div class="hero-btn1">
                    <a href="{{ route('apply-now.page') }}" class="vl-btn1">Apply Now<i class="fa-solid fa-arrow-right"></i></a>
                  </div>
                </div>
                  <div class="vl-header-action-item d-block d-lg-none">
                      <button type="button" class="vl-offcanvas-toggle">
                        <i class="fa-solid fa-bars-staggered"></i>
                      </button>
                   </div>
              </div>
          </div>
      </div>
  </div>
</header>
 <!--=====HEADER END =======-->

<!--===== MOBILE HEADER STARTS =======-->
<div class="homepage1-body">
  <div class="vl-offcanvas">
    <div class="vl-offcanvas-wrapper">
        <div class="vl-offcanvas-header d-flex justify-content-between align-items-center mb-90">
            <div class="vl-offcanvas-logo">
                <a href="index.html"><img src="assets/img/logo/logo1.png" alt=""></a>
            </div>
            <div class="vl-offcanvas-close">
               <button class="vl-offcanvas-close-toggle"><i class="fa-solid fa-xmark"></i></button>
            </div>
        </div>

        <div class="vl-offcanvas-menu d-lg-none mb-40">
            <nav></nav>
        </div>

        <div class="space20"></div>
        <div class="vl-offcanvas-info">
            <h3 class="vl-offcanvas-sm-title">Contact Us</h3>
            <div class="space20"></div>
            <span><a href="https://www.wa.me/+4917685595503"> <i class="fa-regular fa-envelope"></i> +49 176 855 9550 3</a></span>
            <span><a href="mailto:info@faststudentjobs.com"><i class="fa-solid fa-phone"></i> info@faststudentjobs.com</a></span>
            <span><a href="#"><i class="fa-solid fa-location-dot"></i> Berlin, Germany</a></span>
        </div>
        <div class="space20"></div>
        <div class="vl-offcanvas-social">
            <h3 class="vl-offcanvas-sm-title">Follow Us</h3>
            <div class="space20"></div>
            <a href="#" ><i class="fab fa-facebook-f"></i></a>
            <a href="#"><i class="fab fa-twitter"></i></a>
            <a href="#"><i class="fab fa-linkedin-in"></i></a>
            <a href="#"><i class="fab fa-instagram"></i></a>
         </div>

    </div>
</div>
<div class="vl-offcanvas-overlay"></div>
</div>