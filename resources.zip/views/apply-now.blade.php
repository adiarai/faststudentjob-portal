@extends('layout')

@section('main-content')
<style>
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }

  
    @media screen and (max-width:500px){
    .inner-header-area{
        display:none;
    }
  }
</style>
<!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Application form</h1>
                    <div class="space20"></div>
                    <a href="#">Home <i class="fa-solid fa-angle-right"></i> Other <i class="fa-solid fa-angle-right"></i> <span>Apply Now</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="web-assets/img/all-images/hero/hero-img11.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== HERO AREA ENDS =======-->

<!--===== TESTIMONIAL AREA STARTS =======-->
<div class="contact-inner-area sp1">
    <div class="container">

        <div class="space70"></div>
        <div class="row align-items-center">

            @if ($errors->any())
    <div class="alert alert-danger">
        <ul style="margin:0; padding-left: 20px;">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

            @if(session('success'))
    <div style="background: #d4edda; color: #155724; padding: 10px; border:1px solid #c3e6cb; border-radius: 4px; margin-bottom: 15px;">
        {{ session('success') }}
    </div>
@endif
            <div class="col-lg-12">
<form action="{{ route('application.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
            
    <div class="contact-main-boxarea" data-aos="fade-left" data-aos-duration="1200">
                    <h3>Application Form</h3>
                    <div class="space16"></div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <input value="{{ old('full_name') }}" name="full_name" type="text" placeholder="Full Name">
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <input value="{{ old('city') }}" name="city" type="text" placeholder="City">
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <input type="" list="type_job" required  value="{{ old('job_type') }}" name="job_type" placeholder="Type of Job You Want?" >
                                <datalist id="type_job" style="border:1px solid red !important">
                                    <option>Kitchen / Restaurant Helper</option>
                                    <option>Warehouse Worker</option>
                                    <option>Delivery Rider</option>
                                    <option>Cleaning / Housekeeping</option>
                                    <option>Hotel / Hospitality Assistant</option>
                                    <option>Supermarket / Shelf Stacking</option>
                                    <option>Event Staff / Festival Helper</option>
                                    <option>Babysitting / Child Care</option>
                                    <option>Gardening / Outdoor Work</option>
                                    <option>Pet Care / Dog Walking</option>
                                    <option>Moving / Shifting Help</option>
                                    <option>Factory / Production Line</option>
                                    <option>Administrative / Office Support</option>
                                    <option>Private Tutoring / Teaching Assistant</option>
                                    <option>Freelance / Online Work</option>
                                    <option>Other</option>

                                </datalist>
                            </div>
                        </div>

                        <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <input type="number" name="whatsapp" value="{{ old('whatsapp') }}" placeholder="Whatsapp Number">
                            </div>
                        </div>


                         <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <label>Upload CV</label>
                                <input name="cv" type="file">
                            </div>
                        </div>

                         <div class="col-lg-6 col-md-6">
                            <div class="input-area">
                                <label>Email address</label>
                                <input type="email" value="{{ old('email') }}" name="email" placeholder="Email Address">
                            </div>
                        </div>

                        <div class="col-lg-12 col-md-12">
                            <div class="input-area">
                                <textarea name="description"  placeholder="Any other information?">{{ old('description') }}</textarea>
                            </div>
                        </div>

                        <div class="col-lg-12 col-md-12">
                            <div class="input-area text-end">
                                <button type="submit" class="vl-btn1">Send Now <i class="fa-solid fa-arrow-right"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>

    </div>
</div>

<!--===== CTA AREA ENDS =======-->
@endsection
