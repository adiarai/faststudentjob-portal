@extends('layout')
<!--===== MOBILE HEADER STARTS =======-->
@section('main-content')
<style>
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }

  
    @media screen and (max-width:500px){
    .inner-header-area{
        display:none;
    }
  }
</style>
<!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Application Tracking</h1>
                    <div class="space20"></div>
                    <a href="{{ url('/') }}">Home <i class="fa-solid fa-angle-right"></i> <span>Application Tracking</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="{{ asset('web-assets/img/all-images/hero/hero-img11.png')}}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== HERO AREA ENDS =======-->

<!--===== APPLICATION DETAIL AREA STARTS =======-->
<div class="contact-inner-area sp1">
    <div class="container">
        <div class="space70"></div>

        <div class="row">
            <div class="col-lg-10 mx-auto">
                <div class="contact-main-boxarea" data-aos="fade-up" data-aos-duration="1200">
                    <h3 class="text-center">Application Details</h3>
                    <div class="space20"></div>

                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th width="30%">Reference Number</th>
                                    <td><strong>{{ $detail->reference }}</strong></td>
                                </tr>
                                <tr>
                                    <th>Full Name</th>
                                    <td>{{ $detail->full_name }}</td>
                                </tr>
                                <tr>
                                    <th>City</th>
                                    <td>{{ $detail->city }}</td>
                                </tr>
                                <tr>
                                    <th>Job Type</th>
                                    <td>{{ $detail->job_type }}</td>
                                </tr>
                                <tr>
                                    <th>WhatsApp</th>
                                    <td>{{ $detail->whatsapp }}</td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td>{{ $detail->email }}</td>
                                </tr>
                                <tr>
                                    <th>Description</th>
                                    <td>{{ $detail->description }}</td>
                                </tr>
                                <tr>
                                    <th>Submitted On</th>
                                    <td>{{ \Carbon\Carbon::parse($detail->created_at)->format('d M Y, h:i A') }}</td>
                                </tr>
                                <tr>
                                    <th>Status</th>
                                    <td>
                                        @if($detail->status == 'pending')
                                            <span class="badge bg-warning text-dark">Pending</span>
                                        @elseif($detail->status == 'approved')
                                            <span class="badge bg-success">Approved</span>
                                        @elseif($detail->status == 'rejected')
                                            <span class="badge bg-danger">Rejected</span>
                                        @else
                                            <span class="badge bg-secondary">{{ ucfirst($detail->status) }}</span>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <th>Admin Notes</th>
                                    <td>{{ $detail->admin_notes ?? 'No notes added yet.' }}</td>
                                </tr>

                                <tr>
                                    <th>Last Update</th>
                                    <td>{{ \Carbon\Carbon::parse($detail->updated_at)->format('d M Y, h:i A') }}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="text-center mt-4">
                        <a href="{{ url('track-application') }}" class="vl-btn1">Check Another Application</a>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<!--===== APPLICATION DETAIL AREA

@endsection