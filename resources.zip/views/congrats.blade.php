@extends('layout')
<!--===== MOBILE HEADER STARTS =======-->
@section('main-content')
<style>
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }

  
    @media screen and (max-width:500px){
    .inner-header-area{
        display:none;
    }
  }
</style><!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Congratulations!</h1>
                    <div class="space20"></div>
                    <a href="{{ url('/') }}">Home <i class="fa-solid fa-angle-right"></i> <span>Application Submitted</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="{{ asset('web-assets/img/all-images/hero/hero-img11.png')}}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== HERO AREA ENDS =======-->

<!--===== CONGRATULATION AREA STARTS =======-->
<div class="contact-inner-area sp1">
    <div class="container">
        <div class="space70"></div>
        <div class="row align-items-center">
            <div class="col-lg-8 mx-auto text-center">
                <div class="heading1">
                    <h5 data-aos="zoom-in" data-aos-duration="900" style="color:#28a745;">
                        🎉 Congratulations!
                    </h5>
                    <div class="space16"></div>
                    <h2 data-aos="zoom-in" data-aos-duration="1000">
                        Your application has been submitted successfully
                    </h2>
                    <div class="space16"></div>
                    <p style="font-size:18px; line-height:1.6;">
                        Thank you for applying with us.  
                        Your Reference Number is:  
                        <strong style="font-size:22px; color:#FB8500;">{{ $ref_no }}</strong>
                    </p>
                    <div class="space16"></div>
                    <p>
                        Please keep this reference number safe.  
                        You can track your application status anytime using the link below:
                    </p>
                    <div class="space20"></div>
                    <a href="{{ url('track-application') }}" class="btn btn-primary" style="background:#FB8500; border:none; padding:10px 25px; border-radius:6px;">
                        Track My Application
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== CONGRATULATION AREA ENDS =======-->



<!--===== TESTIMONIAL AREA ENDS =======-->

<!--===== CTA AREA STARTS =======-->


@endsection

<!--===== CONFETTI SCRIPT =======-->
<canvas id="confetti-canvas" style="position:fixed; top:0; left:0; width:100%; height:100%; pointer-events:none; z-index:9999;"></canvas>
<script>
// Simple Confetti Animation
const confetti = document.getElementById("confetti-canvas");
const ctx = confetti.getContext("2d");
confetti.width = window.innerWidth;
confetti.height = window.innerHeight;

let particles = [];
for (let i = 0; i < 150; i++) {
    particles.push({
        x: Math.random() * confetti.width,
        y: Math.random() * confetti.height - confetti.height,
        r: Math.random() * 6 + 2,
        d: Math.random() * 150 + 50,
        color: "hsl(" + Math.random() * 360 + ",100%,50%)",
        tilt: Math.floor(Math.random() * 10) - 10
    });
}

function draw() {
    ctx.clearRect(0, 0, confetti.width, confetti.height);
    particles.forEach(p => {
        ctx.beginPath();
        ctx.fillStyle = p.color;
        ctx.fillRect(p.x, p.y, p.r, p.r * 2);
        ctx.fill();
    });
    update();
}

function update() {
    particles.forEach(p => {
        p.y += Math.cos(p.d) + 2;
        p.x += Math.sin(p.d);
        if (p.y > confetti.height) {
            p.x = Math.random() * confetti.width;
            p.y = -10;
        }
    });
}

setInterval(draw, 20);
</script>