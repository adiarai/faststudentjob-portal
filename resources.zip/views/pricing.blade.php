@extends('layout')

@section('main-content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css">

<!-- ======= Page Styles ======= -->
<style>
    .icons {
        padding-top: 15px;
    }
    .arrow {
        display: none;
    }

    /* Visual Enhancements */
    .project-main-content h4 {
        display: flex;
        align-items: center;
        font-weight: 600;
        font-size: 20px;
        margin-top: 30px;
    }

    .project-main-content h4 i {
        margin-right: 10px;
        color: #00B850;
    }

    .policy-section {
        background-color: #f9f9f9;
        border-left: 4px solid #00B850;
        padding: 20px;
        border-radius: 8px;
        margin-bottom: 25px;
    }

    .badge-fee {
        background-color: #ffebeb;
        color: #d10000;
        font-weight: bold;
        padding: 3px 8px;
        border-radius: 4px;
    }

    .table-responsive {
        overflow-x: auto;
    }

    .project-main-content p,
    .project-main-content ul li {
        font-size: 16px;
        line-height: 1.8;
    }

    .cta-box {
        text-align: center;
        margin-top: 40px;
    }

    .cta-box a {
        background-color: #00B850;
        color: white;
        padding: 12px 25px;
        border-radius: 6px;
        text-decoration: none;
        font-weight: 500;
        transition: background 0.3s ease;
    }

    .cta-box a:hover {
        background-color: #0056b3;
    }
</style>

<!-- ===== HERO AREA STARTS ===== -->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Pricing & Payments</h1>
                    <div class="space20"></div>
                    <a href="#">Home <i class="fa-solid fa-angle-right"></i> Pricing & Policies <i class="fa-solid fa-angle-right"></i> <span>Pricing & Payments</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="web-assets/img/all-images/hero/hero-img11.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ===== HERO AREA ENDS ===== -->

<!-- ===== CONTENT SECTION ===== -->
<div class="project-details-section sp1">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 m-auto">
                <div class="project-main-content heading1">
                    <h2>Pricing, Cancellation & Payment Policy</h2>
                    <div class="space16"></div>
                    <p>We aim to provide fast and effective job placement assistance. Please read and agree to the following terms before using our service.</p>

                    <!-- Service Fee -->
                    <div class="policy-section" id="service-fee">
                        <h4><i class="las la-coins"></i> 1. Service Fee</h4>
                        <ul>
                            <li>Only <span class="badge-fee">€250</span> is charged after you get hired through us.</li>
                            <li>No upfront payment required.</li>
                        </ul>
                    </div>

                    <!-- Payment Timing -->
                    <div class="policy-section">
                        <h4><i class="las la-clock"></i> 2. When You Pay</h4>
                        <ul>
                            <li>You must pay the <span class="badge-fee">€250</span> service fee within 7 days of:
                                <ul>
                                    <li>Accepting a job arranged through us, OR</li>
                                    <li>Deliberately rejecting a job offer arranged through us</li>
                                </ul>
                            </li>
                        </ul>
                    </div>

                    <!-- Cancellation -->
                    <div class="policy-section">
                        <h4><i class="las la-ban"></i> 3. Cancellation Policy</h4>
                        <ul>
                            <li>Cancel within 2 days: <strong>Free — <span class="badge-fee">€0</span></strong></li>
                            <li>Cancel after 2 days: <strong><span class="badge-fee">€50</span> cancellation fee</strong></li>
                        </ul>
                    </div>

                    <!-- Late Payment -->
                    <div class="policy-section">
                        <h4><i class="las la-hourglass-half"></i> 4. Late Payment Fee</h4>
                        <p>If you fail to pay the required fee within 7 days, a <span class="badge-fee">€25</span> late fee applies.</p>
                        <p><em>Example:</em><br>
                        - €50 unpaid cancellation → total: <strong>€75</strong><br>
                        - €250 unpaid service fee → total: <strong>€275</strong></p>
                    </div>

                    <!-- Job Offer Rejection -->
                    <div class="policy-section">
                        <h4><i class="las la-user-times"></i> 5. Job Offer Rejection Policy</h4>
                        <ul>
                            <li>If you:
                                <ul>
                                    <li>Reject the offer</li>
                                    <li>Ignore our communication</li>
                                    <li>Get hired and avoid payment</li>
                                </ul>
                            </li>
                            <li>You still owe the <span class="badge-fee">€250</span> fee within 7 days or face a late fee.</li>
                        </ul>
                    </div>

                    <!-- No Job Guarantee -->
                    <div class="policy-section">
                        <h4><i class="las la-thumbs-up"></i> 6. No Job – No Payment Guarantee</h4>
                        <p>If we can’t place you within 2 months, you owe nothing.</p>
                    </div>

                    <!-- Refund -->
                    <div class="policy-section">
                        <h4><i class="las la-undo"></i> 7. Refund Policy</h4>
                        <p>Since there’s no upfront fee, no refunds are applicable.</p>
                    </div>

                    <!-- Legal Enforcement -->
                    <div class="policy-section">
                        <h4><i class="las la-balance-scale"></i> 8. Legal Enforcement</h4>
                        <p>Unpaid dues without valid reason may lead to termination and legal action under German law.</p>
                    </div>

                    <!-- Summary Table -->
                    <div class="policy-section">
                        <h4><i class="las la-table"></i> Quick Summary Table</h4>
                        <div class="table-responsive">
                            <table class="table table-bordered mt-2">
                                <thead>
                                    <tr>
                                        <th>Situation</th>
                                        <th>Fee</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Cancel within 2 days</td>
                                        <td>€0</td>
                                    </tr>
                                    <tr>
                                        <td>Cancel after 2 days</td>
                                        <td>€50</td>
                                    </tr>
                                    <tr>
                                        <td>Cancel after 2 days but don’t pay in 7 days</td>
                                        <td>€75</td>
                                    </tr>
                                    <tr>
                                        <td>Get hired or reject job</td>
                                        <td>€250</td>
                                    </tr>
                                    <tr>
                                        <td>Don’t pay within 7 days</td>
                                        <td>€275</td>
                                    </tr>
                                    <tr>
                                        <td>No job within 2 months</td>
                                        <td>€0</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Call to Action -->
                    <div class="cta-box">
                        <a href="/contact">Have Questions? Contact Us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
