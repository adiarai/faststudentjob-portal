@extends('layout')

@section('main-content')

<!-- ===== Page-specific Styles ===== -->
<style>
    .icons {
        padding-top: 15px;
    }

    .arrow {
        display: none;
    }

    .terms-section {
        background-color: #fdfdfd;
        border-left: 4px solid #00B850;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        margin-bottom: 30px;
    }

    .terms-section h3 {
        font-size: 22px;
        font-weight: 600;
        color: #333;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
    }

    .terms-section h3 i {
        margin-right: 10px;
        color: #00B850;
    }

    .terms-section p {
        font-size: 16px;
        line-height: 1.8;
        color: #555;
    }

    .terms-section ul {
        padding-left: 0;
        list-style: none;
        margin-top: 15px;
    }

    .terms-section ul li {
        font-size: 16px;
        margin-bottom: 12px;
        color: #444;
        display: flex;
        align-items: center;
    }

    .terms-section ul li img {
        margin-right: 10px;
        width: 18px;
    }

    .progress-container {
        margin-top: 20px;
    }

    .progress-container .label {
        display: flex;
        justify-content: space-between;
        font-weight: 500;
        font-size: 14px;
        margin-bottom: 5px;
    }

    .progress-bar {
        background-color: #e9ecef;
        border-radius: 20px;
        overflow: hidden;
        height: 12px;
    }

    .progress-fill {
        height: 12px;
        background: linear-gradient(90deg, #00B850, #00C9A7);
        border-radius: 20px;
    }

    .cta-box {
        text-align: center;
        margin-top: 40px;
    }

    .cta-box a {
        background-color: #00B850;
        color: white;
        padding: 12px 30px;
        border-radius: 6px;
        text-decoration: none;
        font-weight: 500;
        transition: background 0.3s ease;
    }

    .cta-box a:hover {
        background-color: #00B850;
    }
</style>

<!-- ===== HERO AREA STARTS ===== -->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Terms & Conditions</h1>
                    <div class="space20"></div>
                    <a href="#">Home <i class="fa-solid fa-angle-right"></i> Pricing & Policies <i class="fa-solid fa-angle-right"></i> <span>Terms & Conditions</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="{{ asset('web-assets/img/all-images/hero/hero-img11.png') }}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ===== HERO AREA ENDS ===== -->

<!-- ===== TERMS CONTENT SECTION ===== -->
<div class="project-details-section sp1">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 m-auto">
                <div class="project-main-content heading1">
                    <h2>Terms & Conditions</h2>
                    <div class="space16"></div>
                    <p>By using QuickStudentJobs.com, you agree to the following terms. These terms ensure a professional and transparent process for students seeking job placements through our platform.</p>
<br>    
                    <!-- Section 1 -->
                    <div class="terms-section">
                        <h3><i class="las la-user-check"></i> 1. Service Usage</h3>
                        <ul>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> Our services connect students with job opportunities in Germany.</li>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> QuickStudentJobs.com is not the employer but a placement facilitator.</li>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> We cannot guarantee a job but commit to making reasonable efforts.</li>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> Users must provide truthful and updated information.</li>
                        </ul>
                    </div>

                    <!-- Section 2 -->
                    <div class="terms-section">
                        <h3><i class="las la-euro-sign"></i> 2. Payments & Fees</h3>
                        <ul>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> A €250 fee is only applicable once a job is secured or deliberately rejected.</li>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> Fee must be paid within 7 days of confirmation or rejection.</li>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> Late payments will incur an additional €25 fee.</li>
                        </ul>
                    </div>

                    <!-- Section 3 -->
                    <div class="terms-section">
                        <h3><i class="las la-ban"></i> 3. Cancellation & Refusal</h3>
                        <ul>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> Cancel within 2 days: No cost.</li>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> Cancel after 2 days: €50 cancellation fee.</li>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> Ignoring communication = rejection = full fee required.</li>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> We may refuse service or terminate accounts for abuse.</li>
                        </ul>
                    </div>

                    <!-- Section 4 -->
                    <div class="terms-section">
                        <h3><i class="las la-balance-scale"></i> 4. Legal Compliance</h3>
                        <ul>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> All disputes are subject to German law and jurisdiction.</li>
                            <li><img src="{{ asset('assets/img/icons/check5.svg') }}" alt=""> Users must comply with local labor and immigration laws.</li>
                        </ul>
                    </div>

                    <!-- Progress bars -->
                    <div class="terms-section">
                        <div class="progress-container">
                            <div class="label">
                                <span>Fair Practices</span>
                                <span>100%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: 100%;"></div>
                            </div>
                        </div>

                        <div class="progress-container">
                            <div class="label">
                                <span>Transparency</span>
                                <span>99%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: 99%;"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Commitment -->
                    <div class="terms-section">
                        <h3><i class="las la-handshake"></i> Our Commitment</h3>
                        <p>We are committed to offering a fair, transparent, and student-friendly service experience that supports your employment journey in Germany.</p>
                    </div>

                    <!-- Call to Action -->
                    <div class="cta-box">
                        <a href="/contact">Have Questions? Contact Us</a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

@endsection
