@include('header')

<body>
@include('navbar')

  @yield('main-content')


@include('footer')
