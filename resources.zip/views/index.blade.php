@extends('layout')
<!--===== MOBILE HEADER STARTS =======-->
@section('main-content')
<!--===== HERO AREA STARTS =======-->
<style>
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }
  
  @media screen and (max-width:768px){
    #responsive_img1{
      height:280px !important;
    }
  }
  
</style>

@php
    $userAgent = request()->header('User-Agent');
@endphp
@if(strpos($userAgent, 'iPhone') !== false)
    <style>
        @media screen and (max-width: 500px) {
             #img1{
      height:280px !important;
      border:1px solid red;
    }
        }
    </style>
@endif
<div class="main-section-area">
  <div class="hero1" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-size: cover; background-repeat: no-repeat;"
>
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="hero-header-area">
            <h5 data-aos="fade-left" data-aos-duration="900">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                <path d="M9.45001 17.8772C14.2115 17.6442 18 13.7338 18 8.94408C18 7.4743 17.6433 6.08732 17.0111 4.86399C14.4764 6.3183 13.2091 7.04546 12.2507 8.02546C11.1061 9.19582 10.2724 10.6308 9.82481 12.201C9.45001 13.5159 9.45001 14.9697 9.45001 17.8772Z" fill="#00B850"/>
                <path d="M8.55001 17.8772C3.78851 17.6442 0 13.7338 0 8.94408C0 7.47429 0.356744 6.08731 0.988876 4.86398C3.52358 6.3183 4.79093 7.04546 5.74937 8.02547C6.89397 9.19583 7.72761 10.6308 8.17521 12.2011C8.55001 13.5159 8.55001 14.9697 8.55001 17.8772Z" fill="#00B850"/>
                <path d="M1.43959 4.08981C3.97405 5.54399 5.24127 6.27107 6.57492 6.60594C8.16664 7.00559 9.83338 7.00559 11.4251 6.60594C12.7587 6.27108 14.026 5.54399 16.5604 4.08982C14.9571 1.62862 12.1699 0 9 0C5.8301 0 3.04295 1.62862 1.43959 4.08981Z" fill="#00B850"/>
              </svg>
              Fast Jobs for Students in Germany
            </h5>

            <div class="space16"></div>

            <h1 data-aos="fade-left" data-aos-duration="1000">
              Find Work Fast with Fast Student Jobs
            </h1>

            <div class="space16"></div>

            <p data-aos="fade-left" data-aos-duration="1100">
              Looking for kitchen, delivery or warehouse work? 
              Fast Student Jobs helps students & job seekers in Germany get hired quickly.
            </p>

            <div class="space32"></div>

            <div class="btn-area1" data-aos="fade-left" data-aos-duration="1200">
              <a href="{{ route('apply-now.page') }}" class="vl-btn1">Apply Now <i class="fa-solid fa-arrow-right"></i></a>
              <a href="contact" class="vl-btn1 btn2">Contact Us <i class="fa-solid fa-arrow-right"></i></a>
            </div>
          </div>

        </div>
        <div class="col-lg-6">
          <div class="hero-main-img" data-aos="fade-right" data-aos-duration="1000">
            <img src="{{ asset('web-assets/img/elements/elements1.png') }}"
 alt="" class="elements1 keyframe5">
            <div class="img1">
              <img src="{{ asset('web-assets/img/all-images/hero/hero-img1.png') }}"
 alt="">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="counter-section-area">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="row">
            <div class="col-lg-4 col-6 col-md-4">
              <div class="counter-boxarea">
                <h2><span class="counter">1</span>K+</h2>
                <div class="space16"></div>
                <p>Happy Customers</p>
              </div>
            </div>

            <div class="col-lg-4 col-6 col-md-4">
              <div class="counter-boxarea">
                <h2><span class="counter">98</span>%</h2>
                <div class="space16"></div>
                <p>Project Completed</p>
              </div>
            </div>

            <div class="col-lg-4 col-6 col-md-4">
              <div class="space20 d-md-none d-block"></div>
              <div class="counter-boxarea">
                <h2><span class="counter">697</span>+</h2>
                <div class="space16"></div>
                <p>Employer Solutions</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--===== HERO AREA ENDS =======-->

<!--===== ABOUT AREA STARTS =======-->
<div class="about1 sp1">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <div class="about-images" data-aos="zoom-out" data-aos-duration="1000">
          <img src="web-assets/img/elements/elements1.png" alt="" class="elements1 keyframe5">
          <div class="img1">
            <img src="web-assets/img/all-images/about/about-img1.png" alt="">
          </div>
        </div>
      </div>

<div class="col-lg-6">
    <div class="about-heading heading1">
        <h5 class="vl-section-subtitle" data-aos="fade-left" data-aos-duration="900">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                <path d="M9.45001 17.8772C14.2115 17.6442 18 13.7338 18 8.94408C18 7.4743 17.6433 6.08732 17.0111 4.86399C14.4764 6.3183 13.2091 7.04546 12.2507 8.02546C11.1061 9.19582 10.2724 10.6308 9.82481 12.201C9.45001 13.5159 9.45001 14.9697 9.45001 17.8772Z" fill="#00B850"/>
                <path d="M8.55001 17.8772C3.78851 17.6442 0 13.7338 0 8.94408C0 7.47429 0.356744 6.08731 0.988876 4.86398C3.52358 6.3183 4.79093 7.04546 5.74937 8.02547C6.89397 9.19583 7.72761 10.6308 8.17521 12.2011C8.55001 13.5159 8.55001 14.9697 8.55001 17.8772Z" fill="#00B850"/>
                <path d="M1.43959 4.08981C3.97405 5.54399 5.24127 6.27107 6.57492 6.60594C8.16664 7.00559 9.83338 7.00559 11.4251 6.60594C12.7587 6.27108 14.026 5.54399 16.5604 4.08982C14.9571 1.62862 12.1699 0 9 0C5.8301 0 3.04295 1.62862 1.43959 4.08981Z" fill="#00B850"/>
            </svg>
            ABOUT US
        </h5>
        <div class="space16"></div>
        <h2 class="vl-section-title" data-aos="fade-left" data-aos-duration="1000">
            Connecting Students with Fast Job Opportunities in Germany
        </h2>
        <div class="space16"></div>
        <p data-aos="fade-left" data-aos-duration="1100">
            Fast Student Jobs helps international students and job seekers find kitchen, cleaning, warehouse, and delivery jobs across Germany.
            We focus on fast connections and personal guidance so you can start working quickly.
        </p>

        <div class="row">
            <div class="col-lg-6 col-md-6" data-aos="zoom-in" data-aos-duration="900">
                <div class="about-boxarea">
                    <div class="icons">
                        <img src="web-assets/img/icons/about-icons1.svg" alt="">
                    </div>
                    <div class="space24"></div>
                    <div class="texrarea">
                        <a href="javascript:void(0)" class="title">Fast, Personal Job Support</a>
                        <div class="space24"></div>
                        <p>Apply online or via contact and we quickly connect you with jobs that match your city and skills.</p>
                    </div>
                </div>
            </div>
<div class="col-lg-6 col-md-6" data-aos="zoom-in" data-aos-duration="1000">
    <div class="about-boxarea">
        <div class="icons">
            <img src="web-assets/img/icons/about-icons2.svg" alt="">
        </div>
        <div class="space24"></div>
        <div class="texrarea">
            <a href="javascript:void(0)" class="title">Simple Payment After Hiring</a>
            <div class="space24"></div>
            <p>
                You pay €250 only after you are hired or reject a job arranged by us. 
                If payment is delayed more than 7 days, a €25 late fee will apply.
            </p>
        </div>
    </div>
</div>

        </div>

        <div class="space32"></div>
        <div class="btn-area1" data-aos="fade-left" data-aos-duration="1200">
            <a href="about" class="vl-btn1">Learn More <i class="fa-solid fa-arrow-right"></i></a>
        </div>
    </div>
</div>

    </div>
  </div>
</div>
<!--===== ABOUT AREA ENDS =======-->

<!--===== SERVICE AREA STARTS =======-->
<div class="service1 sp2" style="background-image: url(web-assets/img/all-images/bg/section-bg1.png); background-position: center; background-repeat: no-repeat; background-size: cover;">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 m-auto">
        <div class="heading1 text-center space-margin60">
          <h5 class="vl-section-subtitle" data-aos="zoom-in" data-aos-duration="900">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M9.45001 17.8772C14.2115 17.6442 18 13.7338 18 8.94408C18 7.4743 17.6433 6.08732 17.0111 4.86399C14.4764 6.3183 13.2091 7.04546 12.2507 8.02546C11.1061 9.19582 10.2724 10.6308 9.82481 12.201C9.45001 13.5159 9.45001 14.9697 9.45001 17.8772Z" fill="#00B850"/>
              <path d="M8.55001 17.8772C3.78851 17.6442 0 13.7338 0 8.94408C0 7.47429 0.356744 6.08731 0.988876 4.86398C3.52358 6.3183 4.79093 7.04546 5.74937 8.02547C6.89397 9.19583 7.72761 10.6308 8.17521 12.2011C8.55001 13.5159 8.55001 14.9697 8.55001 17.8772Z" fill="#00B850"/>
              <path d="M1.43959 4.08981C3.97405 5.54399 5.24127 6.27107 6.57492 6.60594C8.16664 7.00559 9.83338 7.00559 11.4251 6.60594C12.7587 6.27108 14.026 5.54399 16.5604 4.08982C14.9571 1.62862 12.1699 0 9 0C5.8301 0 3.04295 1.62862 1.43959 4.08981Z" fill="#00B850"/>
            </svg> Our Services
          </h5>
          <div class="space16"></div>
          <h2 class="vl-section-title" data-aos="zoom-in" data-aos-duration="1000">
            Jobs for Students and Job Seekers Across Germany
          </h2>
          <div class="space16"></div>
          <p data-aos="zoom-in" data-aos-duration="1100">
            Fast Student Jobs helps you find fast, flexible work opportunities in Germany — with step-by-step guidance until you’re hired.
          </p>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-4" data-aos="fade-right" data-aos-duration="1000">
        <div class="service-boxarea">
          <div class="img1">
            <img id="responsive_img1" src="web-assets/img/all-images/service/service-img1.png" alt="">
          </div>
          <div class="space24"></div>
          <div class="content-area">
            <a href="javascript:void(0)" class="title">Kitchen & Restaurant Jobs</a>
            <div class="space16"></div>
            <p>Find work as a kitchen helper, dishwasher, or restaurant staff in your city — no experience needed.</p>
            <div class="space24"></div>
            <div class="btn-area1">
              <a href="about" class="vl-btn1">Learn More <i class="fa-solid fa-arrow-right"></i></a>
            </div>
          </div>
        </div>
      </div>

      <div class="col-lg-8">
        <div class="row">
          <div class="col-lg-12" data-aos="fade-left" data-aos-duration="1100">
            <div class="service-boxarea">
              <div class="row align-items-center">
                <div class="col-lg-5">
                  <div class="img1" id="img1">
                    <img src="web-assets/img/all-images/service/service-img2.webp" alt="">
                  </div>
                </div>
                <div class="col-lg-7">
                  <div class="space24 d-lg-none d-block"></div>
                  <div class="content-area">
                    <a href="javascript:void(0)" class="title">Cleaning & Housekeeping Jobs</a>
                    <div class="space16"></div>
                    <p>We help students and job seekers connect with cleaning jobs in hotels, offices, and private homes.</p>
                    <div class="space24"></div>
                    <div class="btn-area1">
                      <a href="about" class="vl-btn1">Learn More <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="row">
          <div class="col-lg-6 col-md-6" data-aos="fade-up" data-aos-duration="1200" data-aos-offset="100">
            <div class="service-boxarea2">
              <div class="content-area">
                <a href="javascript:void(0)" class="title">Warehouse & Logistics Jobs</a>
                <div class="space16"></div>
                <p>Apply for warehouse packing, sorting, and loading jobs. We match you to opportunities in your area.</p>
                <div class="space24"></div>
                <div class="btn-area1">
                  <a href="about" class="vl-btn1">Learn More <i class="fa-solid fa-arrow-right"></i></a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-6 col-md-6" data-aos="fade-up" data-aos-duration="1300" data-aos-offset="120">
            <div class="service-boxarea2">
              <div class="content-area">
                <a href="javascript:void(0)" class="title">Delivery & Driving Jobs</a>
                <div class="space16"></div>
                <p>Join delivery services or local businesses as a rider or driver. Fast hiring with our personal help.</p>
                <div class="space24"></div>
                <div class="btn-area1">
                  <a href="about" class="vl-btn1">Learn More <i class="fa-solid fa-arrow-right"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--===== SERVICE AREA ENDS =======-->

<!--===== WORK AREA STARTS =======-->
<div class="work1 sp1">
  <div class="container">
    <div class="row">
      <div class="col-lg-7 m-auto">
        <div class="heading1 text-center space-margin60">
          <h5 class="vl-section-subtitle" data-aos="zoom-in" data-aos-duration="900">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M9.45001 17.8772C14.2115 17.6442 18 13.7338 18 8.94408C18 7.4743 17.6433 6.08732 17.0111 4.86399C14.4764 6.3183 13.2091 7.04546 12.2507 8.02546C11.1061 9.19582 10.2724 10.6308 9.82481 12.201C9.45001 13.5159 9.45001 14.9697 9.45001 17.8772Z" fill="#00B850"/>
              <path d="M8.55001 17.8772C3.78851 17.6442 0 13.7338 0 8.94408C0 7.47429 0.356744 6.08731 0.988876 4.86398C3.52358 6.3183 4.79093 7.04546 5.74937 8.02547C6.89397 9.19583 7.72761 10.6308 8.17521 12.2011C8.55001 13.5159 8.55001 14.9697 8.55001 17.8772Z" fill="#00B850"/>
              <path d="M1.43959 4.08981C3.97405 5.54399 5.24127 6.27107 6.57492 6.60594C8.16664 7.00559 9.83338 7.00559 11.4251 6.60594C12.7587 6.27108 14.026 5.54399 16.5604 4.08982C14.9571 1.62862 12.1699 0 9 0C5.8301 0 3.04295 1.62862 1.43959 4.08981Z" fill="#00B850"/>
            </svg> How It Works
          </h5>
          <div class="space16"></div>
          <h2 class="vl-section-title" data-aos="zoom-in" data-aos-duration="1000">
            Simple, Fast and Reliable
          </h2>
          <div class="space16"></div>
          <p data-aos="zoom-in" data-aos-duration="1100">
            With Fast Student Jobs, getting a part-time job in Germany is as easy as 1-2-3-4.
          </p>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-6">
        <!-- Step 2 -->
        <div class="works-main-widget-area" data-aos="zoom-in-up" data-aos-duration="900">
          <div class="text-end">
            <div class="icons">
              <img src="web-assets/img/icons/w-icons8.svg" alt="">
            </div>
          </div>
          <div class="space70 d-lg-block d-none"></div>
          <div class="space30 d-lg-none d-block"></div>
          <div class="works8-boxarea">
            <a href="#">We Match You</a>
            <div class="space16"></div>
            <p>We review your application and connect you with jobs that fit your skills and location.</p>
            <h5>02</h5>
          </div>
        </div>
        <!-- Step 4 -->
        <div class="works-main-widget-area" data-aos="zoom-in-up" data-aos-duration="1000">
          <div class="space70 d-lg-block d-none"></div>
          <div class="space30 d-lg-none d-block"></div>
          <div class="text-end">
            <div class="icons">
              <img src="web-assets/img/icons/w-icons10.svg" alt="">
            </div>
          </div>
          <div class="space70 d-lg-block d-none"></div>
          <div class="space30 d-lg-none d-block"></div>
          <div class="works8-boxarea">
  <a href="#">Pay After You’re Hired</a>
  <div class="space16"></div>
  <p>Once you're hired or reject a job we arrange, pay the €250 service fee within 7 days. A €25 late fee applies after that.</p>
  <h5>04</h5>
</div>

        </div>
      </div>

      <div class="col-lg-6">
        <div class="space30 d-lg-none d-block"></div>
        <div class="works-main-widget-area2">
          <!-- Step 1 -->
          <div class="works8-boxarea" data-aos="zoom-in-up" data-aos-duration="1100">
            <a href="#">Apply Online or Contact</a>
            <div class="space16"></div>
            <p>Fill out our form or contact us with your details and job preference.</p>
            <h5>01</h5>
          </div>
          <div class="space70 d-lg-block d-none"></div>
          <div class="space30 d-lg-none d-block"></div>
          <div class="text-start">
            <div class="icons">
              <img src="web-assets/img/icons/w-icons8.svg" alt="">
            </div>
          </div>
          <div class="space70 d-lg-block d-none"></div>
          <div class="space30 d-lg-none d-block"></div>
        </div>

        <div class="works-main-widget-area2" data-aos="zoom-in-up" data-aos-duration="1200">
          <!-- Step 3 -->
          <div class="works8-boxarea">
            <a href="#">Get Hired Quickly</a>
            <div class="space16"></div>
            <p>We help you schedule interviews or trials quickly so you can start earning as soon as possible.</p>
            <h5>03</h5>
          </div>
          <div class="space70 d-lg-block d-none"></div>
          <div class="space30 d-lg-none d-block"></div>
          <div class="text-start">
            <div class="icons">
              <img src="web-assets/img/icons/w-icons10.svg" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--===== WORK AREA ENDS =======-->


<!--===== TESTIMONISL AREA STARTS =======-->
<div class="testi1 sp1" style="background-image: url(web-assets/img/all-images/bg/section-bg2.png); background-position: center; background-repeat: no-repeat; background-size: cover;">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="testimonial-img1" data-aos="zoom-out" data-aos-duration="1000">
          <img src="web-assets/img/all-images/testimonial/testimonial-img1.png" alt="">
        </div>
      </div>

      <div class="col-lg-6">
        <div class="testimonial-slider-title heading1">
         <h5 class="vl-section-subtitle" data-aos="zoom-in" data-aos-duration="900"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
          <path d="M9.45001 17.8772C14.2115 17.6442 18 13.7338 18 8.94408C18 7.4743 17.6433 6.08732 17.0111 4.86399C14.4764 6.3183 13.2091 7.04546 12.2507 8.02546C11.1061 9.19582 10.2724 10.6308 9.82481 12.201C9.45001 13.5159 9.45001 14.9697 9.45001 17.8772Z" fill="#00B850"/>
          <path d="M8.55001 17.8772C3.78851 17.6442 0 13.7338 0 8.94408C0 7.47429 0.356744 6.08731 0.988876 4.86398C3.52358 6.3183 4.79093 7.04546 5.74937 8.02547C6.89397 9.19583 7.72761 10.6308 8.17521 12.2011C8.55001 13.5159 8.55001 14.9697 8.55001 17.8772Z" fill="#00B850"/>
          <path d="M1.43959 4.08981C3.97405 5.54399 5.24127 6.27107 6.57492 6.60594C8.16664 7.00559 9.83338 7.00559 11.4251 6.60594C12.7587 6.27108 14.026 5.54399 16.5604 4.08982C14.9571 1.62862 12.1699 0 9 0C5.8301 0 3.04295 1.62862 1.43959 4.08981Z" fill="#00B850"/>
        </svg> Testimonial</h5>
        <div class="space16"></div>
        <h2 class="vl-section-title" data-aos="zoom-in" data-aos-duration="1000">Trusted by Businesses and Professionals</h2>
        <div class="space48"></div>
        <div class="testimonial-slider">
          <div class="testimonial-boxarea">
            <ul>
              <li><i class="fa-solid fa-star"></i></li>
              <li><i class="fa-solid fa-star"></i></li>
              <li><i class="fa-solid fa-star"></i></li>
              <li><i class="fa-solid fa-star"></i></li>
              <li><i class="fa-solid fa-star"></i></li>
            </ul>
            <div class="space20"></div>
            <p class="pera">“We take pride in the lasting relationships we build with our clients and candidates. Their success is our success, & nothing speaks louder than their stories.”</p>
            <div class="space32"></div>
            <div class="author-images-area">
              <div class="auhtor-images">
                <div class="img1">
                  <img src="web-assets/img/all-images/others/author-img1.png" alt="">
                </div>
                <div class="text">
                  <a href="#">Alex Ferguson</a>
                  <div class="space16"></div>
                  <p>CEO, Ranboz Ltd</p>
                </div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
                <g clip-path="url(#clip0_328_3846)">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M24 30L27.2 20.1818H24V12L32 12L32 20.1818L28.8 30L24 30Z" fill="white"/>
                  <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M10 30L13.2 20.1818H10V12L18 12V20.1818L14.8 30L10 30Z" fill="white"/>
                </g>
                <defs>
                  <clipPath id="clip0_328_3846">
                    <rect width="40" height="40" fill="white"/>
                  </clipPath>
                </defs>
              </svg>
            </div>
          </div>
          <div class="testimonial-boxarea">
            <ul>
              <li><i class="fa-solid fa-star"></i></li>
              <li><i class="fa-solid fa-star"></i></li>
              <li><i class="fa-solid fa-star"></i></li>
              <li><i class="fa-solid fa-star"></i></li>
              <li><i class="fa-solid fa-star"></i></li>
            </ul>
            <div class="space20"></div>
            <p class="pera">“We take pride in the lasting relationships we build with our clients and candidates. Their success is our success, & nothing speaks louder than their stories.”</p>
            <div class="space32"></div>
            <div class="author-images-area">
              <div class="auhtor-images">
                <div class="img1">
                  <img src="web-assets/img/all-images/others/author-img1.png" alt="">
                </div>
                <div class="text">
                  <a href="#">Alex Ferguson</a>
                  <div class="space16"></div>
                  <p>CEO, Ranboz Ltd</p>
                </div>
              </div>
              <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40" fill="none">
                <g clip-path="url(#clip0_328_3846)">
                  <path fill-rule="evenodd" clip-rule="evenodd" d="M24 30L27.2 20.1818H24V12L32 12L32 20.1818L28.8 30L24 30Z" fill="white"/>
                  <path opacity="0.3" fill-rule="evenodd" clip-rule="evenodd" d="M10 30L13.2 20.1818H10V12L18 12V20.1818L14.8 30L10 30Z" fill="white"/>
                </g>
                <defs>
                  <clipPath id="clip0_328_3846a">
                    <rect width="40" height="40" fill="white"/>
                  </clipPath>
                </defs>
              </svg>
            </div>
          </div>
        </div>

        <div class="testimonial-arrow">
          <div class="prev-arrow1">
            <button><i class="fa-solid fa-arrow-left"></i></button>
          </div>
          <div class="next-arrow1">
            <button><i class="fa-solid fa-arrow-right"></i></button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<!--===== TESTIMONISL AREA ENDS =======-->

<!--===== CASE AREA STARTS =======-->
<div class="case1-section sp1">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-6">
        <div class="heading1 space-margin60">
          <h5 class="vl-section-subtitle" data-aos="zoom-in" data-aos-duration="900"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M9.45001 17.8772C14.2115 17.6442 18 13.7338 18 8.94408C18 7.4743 17.6433 6.08732 17.0111 4.86399C14.4764 6.3183 13.2091 7.04546 12.2507 8.02546C11.1061 9.19582 10.2724 10.6308 9.82481 12.201C9.45001 13.5159 9.45001 14.9697 9.45001 17.8772Z" fill="#00B850"/>
            <path d="M8.55001 17.8772C3.78851 17.6442 0 13.7338 0 8.94408C0 7.47429 0.356744 6.08731 0.988876 4.86398C3.52358 6.3183 4.79093 7.04546 5.74937 8.02547C6.89397 9.19583 7.72761 10.6308 8.17521 12.2011C8.55001 13.5159 8.55001 14.9697 8.55001 17.8772Z" fill="#00B850"/>
            <path d="M1.43959 4.08981C3.97405 5.54399 5.24127 6.27107 6.57492 6.60594C8.16664 7.00559 9.83338 7.00559 11.4251 6.60594C12.7587 6.27108 14.026 5.54399 16.5604 4.08982C14.9571 1.62862 12.1699 0 9 0C5.8301 0 3.04295 1.62862 1.43959 4.08981Z" fill="#00B850"/>
          </svg> Case Studies</h5>
          <div class="space16"></div>
          <h2 class="vl-section-title" data-aos="zoom-in" data-aos-duration="1000">Transforming Businesses, Advancing Careers</h2>
          <div class="space16"></div>
          <p data-aos="zoom-in" data-aos-duration="1100">Our case studies showcase the real-world impact of our staffing solutions. From helping businesses overcome recruitment.</p>
        </div>
      </div>
      <div class="col-lg-4"></div>
      <div class="col-lg-2">
        <div class="testimonial-arrow text-end">
          <div class="prev-arrow">
            <button><i class="fa-solid fa-arrow-left"></i></button>
          </div>
          <div class="next-arrow">
            <button><i class="fa-solid fa-arrow-right"></i></button>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-12" data-aos="zoom-out" data-aos-duration="1000">
        <div class="case-slider-area">
          <div class="case-boxes-area">
            <div class="img1">
              <img src="web-assets/img/all-images/case/case-img1.png" alt="">
            </div>
            <div class="text-area">
              <h5>staffing solution</h5>
              <div class="space16"></div>
              <a href="#" class="title">Career Path Solutions</a>
              <div class="space16"></div>
              <p>Explore we’ve made a difference and discover the possibilities .</p>
              <div class="arrow">
                <a href="#"><i class="fa-solid fa-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="case-boxes-area">
            <div class="img1">
              <img src="web-assets/img/all-images/case/case-img2.png" alt="">
            </div>

            <div class="text-area">
              <h5>staffing solution</h5>
              <div class="space16"></div>
              <a href="#" class="title">Talent Bridge Initiative</a>
              <div class="space16"></div>
              <p>Explore we’ve made a difference and discover the possibilities .</p>
              <div class="arrow">
                <a href="#"><i class="fa-solid fa-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="case-boxes-area">
            <div class="img1">
              <img src="web-assets/img/all-images/case/case-img3.png" alt="">
            </div>
            <div class="text-area">
              <h5>staffing solution</h5>
              <div class="space16"></div>
              <a href="#" class="title">FutureReady Staffing</a>
              <div class="space16"></div>
              <p>Explore we’ve made a difference and discover the possibilities .</p>
              <div class="arrow">
                <a href="#" style="margin-left: 10px"><i class="fa-solid fa-arrow-right"></i></a>
              </div>
            </div>
          </div>

          <div class="case-boxes-area">
            <div class="img1">
              <img src="web-assets/img/all-images/case/case-img4.png" alt="">
            </div>
            <div class="text-area">
              <h5>staffing solution</h5>
              <div class="space16"></div>
              <a href="#" class="title">SuccessMatch Program</a>
              <div class="space16"></div>
              <p>Explore we’ve made a difference and discover the possibilities .</p>
              <div class="arrow">
                <a href="#"><i class="fa-solid fa-arrow-right"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--===== CASE AREA ENDS =======-->
<!--===== BENEFIT AREA STARTS =======-->
<div class="benefit1 sp1" style="background-image: url(web-assets/img/all-images/bg/section-bg1.png); background-position: center; background-repeat: no-repeat; background-size: cover;">
  <div class="container">
    <div class="row">
      <div class="col-lg-7 m-auto">
        <div class="heading1 text-center space-margin60">
          <h5 class="vl-section-subtitle" data-aos="zoom-in" data-aos-duration="900">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M9.45001 17.8772C14.2115 17.6442 18 13.7338 18 8.94408C18 7.4743 17.6433 6.08732 17.0111 4.86399C14.4764 6.3183 13.2091 7.04546 12.2507 8.02546C11.1061 9.19582 10.2724 10.6308 9.82481 12.201C9.45001 13.5159 9.45001 14.9697 9.45001 17.8772Z" fill="#00B850"/>
              <path d="M8.55001 17.8772C3.78851 17.6442 0 13.7338 0 8.94408C0 7.47429 0.356744 6.08731 0.988876 4.86398C3.52358 6.3183 4.79093 7.04546 5.74937 8.02547C6.89397 9.19583 7.72761 10.6308 8.17521 12.2011C8.55001 13.5159 8.55001 14.9697 8.55001 17.8772Z" fill="#00B850"/>
              <path d="M1.43959 4.08981C3.97405 5.54399 5.24127 6.27107 6.57492 6.60594C8.16664 7.00559 9.83338 7.00559 11.4251 6.60594C12.7587 6.27108 14.026 5.54399 16.5604 4.08982C14.9571 1.62862 12.1699 0 9 0C5.8301 0 3.04295 1.62862 1.43959 4.08981Z" fill="#00B850"/>
            </svg> Benefits
          </h5>
          <div class="space16"></div>
          <h2 class="vl-section-title" data-aos="zoom-in" data-aos-duration="1000">Why Choose Fast Student Jobs?</h2>
          <div class="space16"></div>
          <p data-aos="zoom-in" data-aos-duration="1100">Fast, reliable, and personalized job placement service tailored for international students and job seekers in Germany.</p>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-lg-6">
        <div class="benefit-boxes-area">
          <ul class="nav nav-pills" id="pills-tab" role="tablist">
            <li class="nav-item" role="presentation" data-aos="fade-left" data-aos-duration="800">
              <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">
                <span class="button-content">
                  <span class="icons"><img src="web-assets/img/icons/bene-icons4.svg" alt=""></span>
                  <span class="text">
                    <span class="title">Trusted Local Jobs</span>
                    <span class="pera">We connect you with verified local employers offering easy part-time and odd jobs across Germany.</span>
                  </span>
                </span>
              </button>
            </li>
            <li class="nav-item" role="presentation" data-aos="fade-left" data-aos-duration="900">
              <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">
                <span class="button-content">
                  <span class="icons"><img src="web-assets/img/icons/bene-icons3.svg" alt=""></span>
                  <span class="text">
                    <span class="title">Personalized Job Matching</span>
                    <span class="pera">We tailor job opportunities to your preferences, skills, and location for a perfect fit.</span>
                  </span>
                </span>
              </button>
            </li>
            <li class="nav-item" role="presentation" data-aos="fade-left" data-aos-duration="1000">
              <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">
                <span class="button-content">
                  <span class="icons"><img src="web-assets/img/icons/bene-icons2.svg" alt=""></span>
                  <span class="text">
                    <span class="title">Simple Application Process</span>
                    <span class="pera">Apply easily online or via WhatsApp with a quick form to start your job search instantly.</span>
                  </span>
                </span>
              </button>
            </li>
            <li class="nav-item" role="presentation" data-aos="fade-left" data-aos-duration="1100">
              <button class="nav-link" id="pills-contact1-tab" data-bs-toggle="pill" data-bs-target="#pills-contact1" type="button" role="tab" aria-controls="pills-contact1" aria-selected="false">
                <span class="button-content">
                  <span class="icons"><img src="web-assets/img/icons/bene-icons1.svg" alt=""></span>
                 <span class="text">
  <span class="title">Pay After Hiring</span>
  <span class="pera">No payment required upfront. Pay €250 only after you're hired or if you reject a job we arrange.</span>
</span>

                </span>
              </button>
            </li>
          </ul>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="benefit-images-area">
          <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0">
              <div class="images">
                <img src="web-assets/img/all-images/benefit/benefit-img1.png" alt="Trusted Local Jobs">
              </div>
            </div>
            <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">
              <div class="images">
                <img src="web-assets/img/all-images/benefit/benefit-img2.png" alt="Personalized Job Matching">
              </div>
            </div>
            <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
              <div class="images">
                <img src="web-assets/img/all-images/benefit/benefit-img3.png" alt="Simple Application Process">
              </div>
            </div>
            <div class="tab-pane fade" id="pills-contact1" role="tabpanel" aria-labelledby="pills-contact1-tab" tabindex="0">
              <div class="images">
                <img src="web-assets/img/all-images/benefit/benefit-img4.png" alt="Pay After Hiring">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--===== BENEFIT AREA ENDS =======-->




@endsection