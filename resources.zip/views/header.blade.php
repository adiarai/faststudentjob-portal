<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <title>Fast Student Jobs - Easy Jobs for Students in Germany</title>

    <!-- Meta Description -->
    <meta name="description" content="Fast Student Jobs helps international students in Germany find easy jobs like kitchen work, cleaning, delivery, warehouse, supermarket, retail, barista, tutoring, babysitting, admin, part-time, flexible, student-friendly jobs. Pay after hiring." />

    <!-- Meta Keywords -->
    <meta name="keywords" content="student jobs Germany, part-time jobs Germany, easy jobs for students, kitchen jobs, cleaning jobs, delivery jobs, warehouse jobs, retail jobs, supermarket jobs, tutoring jobs, babysitting jobs, admin jobs, flexible jobs, student-friendly jobs, online jobs for students, fast hiring jobs, summer jobs Germany, holiday jobs, side jobs Germany, minijob, Nebenjob, internships Germany, student work, temporary jobs, quick jobs, beginner-friendly jobs, part-time work, paid internships, student employment, job for international students, fast student jobs, low-skill jobs, restaurant jobs, café jobs, barista jobs, hotel jobs, event jobs, package delivery jobs, courier jobs, warehouse assistant, grocery jobs, retail assistant, cleaning assistant, babysitter Germany, online tutoring, tutoring assistant, campus jobs, weekend jobs, evening jobs, student helper, job opportunities for students" />

    <!-- Favicon -->
    <link rel="shortcut icon" href="{{ asset('web-assets/img/logo/fav-logo1.png')}}" type="image/x-icon" />

    <!-- Canonical URL -->
    <link rel="canonical" href="https://faststudentjob.de/" />

    <!-- CSS Plugins -->
    <link rel="stylesheet" href="{{ asset('web-assets/css/plugins/bootstrap.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('web-assets/css/plugins/aos.css') }}" />
    <link rel="stylesheet" href="{{ asset('web-assets/css/plugins/fontawesome.css') }}" />
    <link rel="stylesheet" href="{{ asset('web-assets/css/plugins/magnific-popup.css') }}" />
    <link rel="stylesheet" href="{{ asset('web-assets/css/plugins/slick-slider.css') }}" />
    <link rel="stylesheet" href="{{ asset('web-assets/css/plugins/nice-select.css') }}" />
    <link rel="stylesheet" href="{{ asset('web-assets/css/main.css') }}" />

    <!-- Open Graph / Facebook -->
    <meta property="og:title" content="Fast Student Jobs - Easy Jobs for Students in Germany" />
    <meta property="og:description" content="Find fast and easy jobs for international students in Germany: kitchen, cleaning, delivery, warehouse, retail, tutoring, babysitting, and more. Pay after hiring." />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://faststudentjob.de/" />
    <meta property="og:image" content="{{ asset('web-assets/img/logo/fav-logo1.png') }}" />
    <meta property="og:site_name" content="Fast Student Jobs" />

    <!-- Twitter Card -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="Fast Student Jobs - Easy Jobs for Students in Germany" />
    <meta name="twitter:description" content="Find fast student-friendly jobs across Germany: kitchen, cleaning, delivery, warehouse, retail, tutoring, babysitting, and more." />
    <meta name="twitter:image" content="{{ asset('web-assets/img/logo/fav-logo1.png') }}" />
    <meta name="twitter:site" content="@FastStudentJobs" />

<script type="application/ld+json">
{!! '{
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Fast Student Jobs",
    "url": "https://faststudentjob.de/",
    "logo": "' . asset('web-assets/img/logo/fav-logo1.png') . '",
    "description": "Fast Student Jobs helps international students in Germany find easy jobs like kitchen, cleaning, delivery, warehouse, retail, tutoring, and babysitting jobs.",
    "sameAs": [
        "https://www.facebook.com/FastStudentJobs",
        "https://twitter.com/FastStudentJobs"
    ]
}' !!}
</script>




    <!-- SEO Best Practices -->
    <link rel="alternate" href="https://faststudentjob.de/" hreflang="en" />
</head>
