@extends('layout')
<!--===== MOBILE HEADER STARTS =======-->
@section('main-content')
<style>
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }
</style>
@php
    use Illuminate\Support\Facades\DB;
    $jobTypes =DB::table('job_types')->orderBy('type_name', 'asc')->get();
@endphp
<!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>{{ $data->type_name }}</h1>
                    <div class="space20"></div>
                    <a href="index">Home <i class="fa-solid fa-angle-right"></i> Jobs <i class="fa-solid fa-angle-right"></i>  <span>{{ $data->type_name }}</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="{{ asset('web-assets/img/all-images/hero/hero-img11.png')}}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== HERO AREA ENDS =======-->

<!--===== PROJECT AREA STARTS =======-->
<div class="project-details-section sp1">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="project-side-details">
                    <div class="project-widget-area1">
                    
                         <div class="space32"></div>
                        <div class="categories-area">
                            <h3>Job Types</h3>
                            <div class="space4"></div>
                             <ul style="height:550px;overflow:auto">
                                @foreach($jobTypes as $type)
                                    <li><a href="{{ url('job-types/' . $type->slug) }}">{{ $type->type_name }} <span><i class="fa-solid fa-angle-right"></i></span></a></li>
                                        @endforeach
                            </ul>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-lg-8">
                <div class="project-main-content padding1 heading1">
                    {{-- <h2>{{ $data->type_name }}</h2> --}}
                    <div class="space16"></div>
          {!! html_entity_decode($data->content) !!}



                    <div class="space32"></div>
                    <a href="{{ route('apply-now.page') }}" class="vl-btn1">Apply Now <i class="fa-solid fa-arrow-right"></i></a>
                 
           
                </div>
            </div>
        </div>
    </div>
</div>



@endsection