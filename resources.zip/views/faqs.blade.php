@extends('layout')

@section('main-content')
<style type="text/css">
    body {
        counter-reset: liincreasremnt;
    }

    #count:before {
        counter-increment: liincreasremnt;
        content: counter(liincreasremnt)'. ';
    }
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }
</style>

<!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>FAQs</h1>
                    <div class="space20"></div>
                    <a href="#">Home <i class="fa-solid fa-angle-right"></i> Pricing & Policies <i class="fa-solid fa-angle-right"></i> <span>FAQs</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="web-assets/img/all-images/hero/hero-img11.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== HERO AREA ENDS =======-->
<div class="faq-section sp1">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 m-auto">
        <div class="heading1 text-center">
          <h2>Frequently Asked Questions (FAQ)</h2>
          <div class="space16"></div>
          <p>Understand our pricing, cancellation, and payment policies clearly before using our job placement services.</p>
        </div>
        <div class="space32"></div>

        <div class="accordion" id="faqAccordion">

          <!-- FAQ 1 -->
          <div class="accordion-item">
            <h2 class="accordion-header" id="faqHeadingOne">
              <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseOne" aria-expanded="true" aria-controls="faqCollapseOne">
                Do I have to pay anything upfront?
              </button>
            </h2>
            <div id="faqCollapseOne" class="accordion-collapse collapse show" aria-labelledby="faqHeadingOne" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                No, there is no upfront payment required. You only pay after you get hired through a job arranged by us.
              </div>
            </div>
          </div>

          <!-- FAQ 2 -->
          <div class="accordion-item">
            <h2 class="accordion-header" id="faqHeadingTwo">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseTwo" aria-expanded="false" aria-controls="faqCollapseTwo">
                When do I need to pay the service fee?
              </button>
            </h2>
            <div id="faqCollapseTwo" class="accordion-collapse collapse" aria-labelledby="faqHeadingTwo" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                You are required to pay the €250 service fee within 7 days of either accepting a job arranged through us or deliberately rejecting a job offer.
              </div>
            </div>
          </div>

          <!-- FAQ 3 -->
          <div class="accordion-item">
            <h2 class="accordion-header" id="faqHeadingThree">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseThree" aria-expanded="false" aria-controls="faqCollapseThree">
                What is the cancellation policy?
              </button>
            </h2>
            <div id="faqCollapseThree" class="accordion-collapse collapse" aria-labelledby="faqHeadingThree" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                If you cancel within 2 days of agreeing to our terms, no payment is required. If you cancel after 2 days, a €50 cancellation fee applies.
              </div>
            </div>
          </div>

          <!-- FAQ 4 -->
          <div class="accordion-item">
            <h2 class="accordion-header" id="faqHeadingFour">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseFour" aria-expanded="false" aria-controls="faqCollapseFour">
                What happens if I delay payment?
              </button>
            </h2>
            <div id="faqCollapseFour" class="accordion-collapse collapse" aria-labelledby="faqHeadingFour" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                If you don’t pay the service or cancellation fee within 7 days, a €25 late payment fee will be added.
              </div>
            </div>
          </div>

          <!-- FAQ 5 -->
          <div class="accordion-item">
            <h2 class="accordion-header" id="faqHeadingFive">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseFive" aria-expanded="false" aria-controls="faqCollapseFive">
                What if I reject or ignore a job offer?
              </button>
            </h2>
            <div id="faqCollapseFive" class="accordion-collapse collapse" aria-labelledby="faqHeadingFive" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                If you reject, ignore, or avoid a job arranged for you, the €250 service fee still applies and must be paid within 7 days to avoid the late fee.
              </div>
            </div>
          </div>

          <!-- FAQ 6 -->
          <div class="accordion-item">
            <h2 class="accordion-header" id="faqHeadingSix">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseSix" aria-expanded="false" aria-controls="faqCollapseSix">
                Do I have to pay anything if I don’t get a job?
              </button>
            </h2>
            <div id="faqCollapseSix" class="accordion-collapse collapse" aria-labelledby="faqHeadingSix" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                No, if we are unable to get you hired within 2 months, you do not have to pay anything.
              </div>
            </div>
          </div>

          <!-- FAQ 7 -->
          <div class="accordion-item">
            <h2 class="accordion-header" id="faqHeadingSeven">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faqCollapseSeven" aria-expanded="false" aria-controls="faqCollapseSeven">
                What is your refund policy?
              </button>
            </h2>
            <div id="faqCollapseSeven" class="accordion-collapse collapse" aria-labelledby="faqHeadingSeven" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                Since we do not take any upfront payments, refunds are not applicable.
              </div>
            </div>
          </div>

        </div> <!-- accordion -->
      </div>
    </div>
  </div>
</div>

@endsection
