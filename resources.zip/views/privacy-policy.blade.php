@extends('layout')

@section('main-content')

<!-- ===== Page-specific Styles ===== -->
<style>
    .icons {
        padding-top: 15px;
    }

    .arrow {
        display: none;
    }

    .privacy-section {
        background-color: #fdfdfd;
        border-left: 4px solid #00B850;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        margin-bottom: 30px;
    }

    .privacy-section h3 {
        font-size: 22px;
        font-weight: 600;
        color: #333;
        margin-bottom: 15px;
        display: flex;
        align-items: center;
    }

    .privacy-section h3 i {
        margin-right: 10px;
        color: #00B850;
    }

    .privacy-section p {
        font-size: 16px;
        line-height: 1.8;
        color: #555;
    }

    .side-head ul {
        list-style: none;
        padding-left: 0;
        margin-top: 10px;
    }

    .side-head ul li {
        font-size: 16px;
        color: #444;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
    }

    .side-head ul li img {
        margin-right: 10px;
        width: 18px;
    }

    .progress-container {
        margin-top: 20px;
    }

    .progress-container .label {
        display: flex;
        justify-content: space-between;
        font-weight: 500;
        font-size: 14px;
        margin-bottom: 5px;
    }

    .progress-bar {
        background-color: #e9ecef;
        border-radius: 20px;
        overflow: hidden;
        height: 12px;
    }

    .progress-fill {
        height: 12px;
        background: linear-gradient(90deg, #00B850, #00C9A7);
        border-radius: 20px;
    }

    .cta-box {
        text-align: center;
        margin-top: 40px;
    }

    .cta-box a {
        background-color: #00B850;
        color: white;
        padding: 12px 30px;
        border-radius: 6px;
        text-decoration: none;
        font-weight: 500;
        transition: background 0.3s ease;
    }

    .cta-box a:hover {
        background-color: #00B850;
    }
</style>

<!-- ===== HERO AREA STARTS ===== -->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Privacy Policy</h1>
                    <div class="space20"></div>
                    <a href="#">Home <i class="fa-solid fa-angle-right"></i> Pricing & Policies <i class="fa-solid fa-angle-right"></i> <span>Privacy Policy</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="{{ asset('web-assets/img/all-images/hero/hero-img11.png') }}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ===== HERO AREA ENDS ===== -->

<!-- ===== CONTENT SECTION START ===== -->
<div class="project-details-section sp1">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 m-auto">
                <div class="project-main-content heading1">
                    <h2>Privacy Policy</h2>
                    <div class="space16"></div>

                    <div class="privacy-section">
                        <h3><i class="las la-user-shield"></i> Your Privacy</h3>
                        <p>Your privacy is important to us. Fast Student Jobs collects only the information you provide to help you find a job. We do not share your personal data with third parties except for legitimate purposes related to job placement.</p>
                    </div>

                    <div class="privacy-section">
                        <h3><i class="las la-database"></i> What Data We Collect</h3>
                        <p>We collect your name, contact information, job preferences, and CV to help match you with potential employers. Your data is stored securely and used only for connecting you with job opportunities in line with your preferences.</p>
                    </div>

                    <div class="privacy-section">
                        <h3><i class="las la-user-lock"></i> Your Rights</h3>
                        <p>You may request the deletion of your data at any time by contacting us. We respect your right to privacy and handle your data responsibly.</p>
                    </div>

                    <div class="privacy-section">
                        <h3><i class="las la-list-check"></i> Quick Summary</h3>
                        <div class="side-head">
                            <ul>
                                <li><img src="{{ asset('web-assets/img/icons/check5.svg') }}" alt=""> We collect your name, contact info, job preferences, and CV.</li>
                                <li><img src="{{ asset('web-assets/img/icons/check5.svg') }}" alt=""> Data is stored securely and used only for job matching.</li>
                                <li><img src="{{ asset('web-assets/img/icons/check5.svg') }}" alt=""> No data sharing with third parties except for job placement.</li>
                                <li><img src="{{ asset('web-assets/img/icons/check5.svg') }}" alt=""> You can request data deletion anytime.</li>
                                <li><img src="{{ asset('web-assets/img/icons/check5.svg') }}" alt=""> We use cookies only to improve your website experience.</li>
                            </ul>
                        </div>

                        <div class="progress-container">
                            <div class="label">
                                <span>Data Security</span>
                                <span>100%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: 100%;"></div>
                            </div>
                        </div>

                        <div class="progress-container">
                            <div class="label">
                                <span>Transparency</span>
                                <span>98%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: 98%;"></div>
                            </div>
                        </div>
                    </div>

                    <div class="privacy-section">
                        <h3><i class="las la-handshake"></i> Our Commitment</h3>
                        <p>Fast Student Jobs is committed to protecting your personal information and ensuring a safe, secure experience when using our platform.</p>
                    </div>

                    <div class="cta-box">
                        <a href="/contact">Have Privacy Questions? Contact Us</a>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- ===== CONTENT SECTION ENDS ===== -->

@endsection
