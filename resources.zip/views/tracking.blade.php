@extends('layout')
<!--===== MOBILE HEADER STARTS =======-->
@section('main-content')
<style>
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }

  
    @media screen and (max-width:500px){
    .inner-header-area{
        display:none;
    }
  }
</style>

<!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Application Tracking</h1>
                    <div class="space20"></div>
                    <a href="{{ url('/') }}">Home <i class="fa-solid fa-angle-right"></i> <span>Application Tracking</span></a>
                </div>
                @if(session('success'))
                    <div style="background: #d4edda; color: #155724; padding: 10px; border:1px solid #c3e6cb; border-radius: 4px; margin-bottom: 15px;">
                        {{ session('success') }}
                    </div>
                @endif
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="{{ asset('web-assets/img/all-images/hero/hero-img11.png')}}" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== HERO AREA ENDS =======-->

<!--===== APPLICATION TRACKING AREA STARTS =======-->
<div class="contact-inner-area sp1">
    <div class="container">
        <div class="space70"></div>
        <div class="row align-items-center">
            <div class="col-lg-8 mx-auto">
                <div class="contact-main-boxarea text-center" data-aos="fade-up" data-aos-duration="1200">
                    <h3>Track Your Application</h3>
                    <div class="space16"></div>
                    <p>Please enter your <strong>Reference Number</strong> below to check the current status of your application.  
                       (This reference number was provided after you submitted your application.)</p>
                    <div class="space20"></div>
                    
                  <form action="{{ route('application.track') }}" method="post" class="text-center">
    @csrf

    @if(session('error'))
        <p class="alert alert-danger">{{ session('error') }}</p>
    @endif

    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
            <div class="input-area">
                <input type="text" name="ref_no" placeholder="Enter your Reference Number" required>
            </div>
        </div>
        <div class="col-lg-12 col-md-12 mt-3">
            <button type="submit" class="vl-btn1">Track Application <i class="fa-solid fa-arrow-right"></i></button>
        </div>
    </div>
</form>


                </div>
            </div>
        </div>
    </div>
</div>
<!--===== APPLICATION TRACKING AREA ENDS =======-->

@endsection