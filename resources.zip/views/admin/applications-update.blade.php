@extends('admin.layout')


@section('admin-content')

<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">


<style>
  #editor-container {
    height: 200px;
    background-color: #F0F5F7 !important;
  }
</style>

        <div class="page-content">

          <div class="page-container">


            <div class="page-title-head d-flex align-items-center gap-2">
              <div class="flex-grow-1">
                <h4 class="fs-16 text-uppercase fw-bold mb-0">Application Details</h4>
              </div>

            </div>




            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header border-bottom border-dashed d-flex align-items-center">
                    <h4 class="header-title">Details</h4>
                  </div>

<div class="card-body">

          <form action="{{ route('update-application') }}" method="POST" enctype="multipart/form-data">
    @csrf


        <input type="hidden" name="ref_no" value="{{ $detail->reference }}" class="form-control" required>

    
    <div class="form-group">
        <label>Admin Status *</label>
        <input type="text" name="status" value="{{ $detail->status }}" class="form-control" required>
    </div>

    <div class="form-group mt-3">
        <label>Admin Notes *</label>
        <input type="text" name="admin_notes" value="{{ $detail->admin_notes }}" class="form-control" required>
    </div>

    <hr>


       <div class="form-group mt-5">
        <label>Applicant name *</label>
        <input type="text" name="full_name" value="{{ $detail->full_name }}" class="form-control" required>
    </div>


     <div class="form-group mt-3">
        <label>Job City *</label>
        <input type="text" name="city" value="{{ $detail->city }}" class="form-control" required>
    </div>


      <div class="form-group mt-3">
        <label>Job Type *</label>
        <input type="text" name="job_type" value="{{ $detail->job_type }}" class="form-control" required>
    </div>


          <div class="form-group mt-3">
        <label>Whatsapp *</label>
        <input type="text" name="whatsapp" value="{{ $detail->whatsapp }}" class="form-control" required>
    </div>



           <div class="form-group mt-3">
        <label>Email *</label>
        <input type="text" name="email" value="{{ $detail->email }}" class="form-control" required>
           </div>


    
           
            <div class="form-group mt-3">
        <label>Applicant notes *</label>
        <input type="text" name="description" value="{{ $detail->description }}" name="description" class="form-control" required>
           </div>




    <div class="form-group mt-4">
        <button type="submit" class="btn btn-primary w-100">Update</button>
    </div>
</form>

                  </div> <!-- end card-body -->
                </div> <!-- end card -->
              </div><!-- end col -->
            </div><!-- end row -->


          </div> <!-- container -->


   

@endsection
	