<?php

include '../db.php';

session_start();
session_unset();
session_destroy();
 
?>
 <script type="text/javascript">
 	window.location.href='login';
 </script>