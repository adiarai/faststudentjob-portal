<div class="sidenav-menu show">

            <!-- Brand Logo -->
             <a href="index" class="logo">
                <span class="logo-light">
                    <span class="logo-lg" style="height: 70px;">
                        <!-- <img src="assets/images/logo.png" alt="logo"> -->
                        <h3 style="font-size: 25px;padding: 10px;color: white;">Fast Student Jobs</h3>
                    </span>
                    <span class="logo-sm">
                        <!-- <img src="assets/images/logo-sm.png" alt="small logo"> -->
                    </span>
                </span>

                <span class="logo-dark">
                    <span class="logo-lg">
                        <!-- <img src="assets/images/logo-dark.png" alt="dark logo"> -->
                    </span>
                    <span class="logo-sm">
                        <!-- <img src="assets/images/logo-sm.png" alt="small logo"> -->
                    </span>
                </span>
            </a>

            <!-- Sidebar Hover Menu Toggle Button -->
            <button class="button-sm-hover">
                <i class="ti ti-circle align-middle"></i>
            </button>

            <!-- Full Sidebar Menu Close Button -->
            <button class="button-close-fullsidebar">
                <i class="ti ti-x align-middle"></i>
            </button>

            <div data-simplebar="init" class=""><div class="simplebar-wrapper active" style="margin: 0px;"><div class="simplebar-height-auto-observer-wrapper"><div class="simplebar-height-auto-observer"></div></div><div class="simplebar-mask show"><div class="simplebar-offset" style="right: 0px; bottom: 0px;"><div class="simplebar-content-wrapper active" tabindex="0" role="region" aria-label="scrollable content" style="height: 100%; overflow: hidden;"><div class="simplebar-content show" style="padding: 0px;">

                <!--- Sidenav Menu -->
                <ul class="side-nav">
                    <li class="side-nav-item">
                        <a href="{{ route('admin.dashboard') }}" class="side-nav-link">
                            <span class="menu-icon"><i class="ti ti-dashboard"></i></span>
                            <span class="menu-text"> Dashboard </span>
                        </a>
                    </li>


                      <li class="side-nav-item">
                        <a href="{{ route('admin.applications') }}" class="side-nav-link">
                            <span class="menu-icon"><i class="ti ti-file"></i></span>
                            <span class="menu-text"> Applications </span>
                        </a>
                    </li>

                     <li class="side-nav-item">
                        <a data-bs-toggle="collapse" href="#sidebarInvoice1" aria-expanded="false" aria-controls="sidebarInvoice1" class="side-nav-link">
                            <span class="menu-icon"><i class="ti ti-users"></i></span>
                            <span class="menu-text"> Job Types</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse" id="sidebarInvoice1">
                            <ul class="sub-menu">
                                <li class="side-nav-item">
                                    <a href="{{ route('admin.new-job-type') }}" class="side-nav-link">
                                        <span class="menu-text">Add New</span>
                                    </a>
                                </li>
                                <li class="side-nav-item">
                                    <a href="{{ route('admin.job-type.view') }}" class="side-nav-link">
                                        <span class="menu-text">View all</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>






                        <li class="side-nav-item">
                        <a data-bs-toggle="collapse" href="#sidebarInvoice2" aria-expanded="false" aria-controls="sidebarInvoice1" class="side-nav-link">
                            <span class="menu-icon"><i class="ti ti-users"></i></span>
                            <span class="menu-text"> Job Cities</span>
                            <span class="menu-arrow"></span>
                        </a>
                        <div class="collapse" id="sidebarInvoice2">
                            <ul class="sub-menu">
                                <li class="side-nav-item">
                                    <a href="{{ route('admin.new-job-city') }}" class="side-nav-link">
                                        <span class="menu-text">Add New</span>
                                    </a>
                                </li>
                                <li class="side-nav-item">
                                    <a href="{{ route('admin.job-city.view') }}" class="side-nav-link">
                                        <span class="menu-text">View all</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>



                    <li class="side-nav-item">
                        <a href="{{ route('admin.profile') }}" class="side-nav-link">
                            <span class="menu-icon"><i class="ti ti-user"></i></span>
                            <span class="menu-text"> Profile </span>
                        </a>
                    </li>









                    <li class="side-nav-item">
                        <a href="Logout" class="side-nav-link">
                            <span class="menu-icon"><i class="ti ti-arrow-left"></i></span>
                            <span class="menu-text"> Logout </span>
                        </a>
                    </li>

                 
              
                </ul>


                <div class="clearfix"></div>
            </div></div></div></div><div class="simplebar-placeholder" style="width: 250px; height: 1136px;"></div></div><div class="simplebar-track simplebar-horizontal" style="visibility: hidden;"><div class="simplebar-scrollbar" style="width: 0px; display: none;"></div></div><div class="simplebar-track simplebar-vertical" style="visibility: hidden;"><div class="simplebar-scrollbar" style="height: 0px; transform: translate3d(0px, 0px, 0px); display: none;"></div></div></div>
        </div>