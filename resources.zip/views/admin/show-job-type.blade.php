@extends('admin.layout')


@section('admin-content')

 <div class="page-content">
            <div class="page-container">


                <div class="page-title-head d-flex align-items-center gap-2">
                    <div class="flex-grow-1">
                        <h4 class="fs-16 text-uppercase fw-bold mb-0">Job Types</h4>
                    </div>

                </div>
                

                

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">All Job Types</h4>


                                <ul class="nav nav-tabs nav-bordered mb-3">
                                    <li class="nav-item">
                                        <a href="#basic-datatable-preview" data-bs-toggle="tab" aria-expanded="false"
                                        class="nav-link active">

                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="#basic-datatable-code" data-bs-toggle="tab" aria-expanded="true"
                                    class="nav-link">

                                </a>
                            </li>
                        </ul> <!-- end nav-->

                        <table id="basic-datatable" class="table table-striped dt-responsive nowrap w-100">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Type Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>


                            <tbody>

                              @foreach ($data as $record)
                                  
                                        <tr>
                                            <td>{{ $record->id }}</td>
                                            <td>{{ $record->type_name }}</td>
                                            <td>
                                             <a href="{{ route('admin.job-type.delete', $record->id) }}" class="btn btn-danger btn-sm">Delete</a>
                                            </td>
                                        </tr>

                              @endforeach


                                          
                                    </tbody>
                                </table>
                            </div> <!-- end card body-->
                        </div> <!-- end card -->
                    </div><!-- end col-->
                </div> <!-- end row-->


            </div> <!-- container -->


@endsection