@extends('admin.layout')


@section('admin-content')

        <div class="page-content">

          <div class="page-container">


            <div class="page-title-head d-flex align-items-center gap-2">
              <div class="flex-grow-1">
                <h4 class="fs-16 text-uppercase fw-bold mb-0">Profile Settings</h4>
              </div>

            </div>


@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif


            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header border-bottom border-dashed d-flex align-items-center">
                    <h4 class="header-title">Login Email</h4>
                  </div>

<div class="card-body">

          <form action="{{ route('profile-email-update') }}" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="form-group">
        <label>Email *</label>
        <input type="text" name="email" class="form-control @error('city') is-invalid @enderror" value="{{ $data->email }}" required>
        @error('city')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>


    <div class="form-group mt-4">
        <button type="submit" class="btn btn-primary w-100">Update</button>
    </div>
</form>

                  </div> <!-- end card-body -->
                </div> <!-- end card -->
              </div><!-- end col -->
            </div><!-- end row -->











            
            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header border-bottom border-dashed d-flex align-items-center">
                    <h4 class="header-title">Login Password</h4>
                  </div>

<div class="card-body">

@if(session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
@endif

          <form autocomplete="OFF" action="{{ route('profile-password-update') }}" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="form-group">
        <label>Current Password *</label>
        <input autocomplete="OFF" type="text" name="cur_password" placeholder="Enter current password" class="form-control" required>
    </div>


    <div class="form-group mt-3">
        <label>New Password *</label>
        <input autocomplete="OFF" type="text" name="new_password" placeholder="Enter new password" class="form-control" required>
    </div>


    <div class="form-group mt-3">
        <label>Confirm Password *</label>
        <input autocomplete="OFF" type="text" name="confirm_password" placeholder="Enter confirm password" class="form-control" required>
    </div>


    <div class="form-group mt-4">
        <button type="submit" class="btn btn-primary w-100">Update</button>
    </div>
</form>

                  </div> <!-- end card-body -->
                </div> <!-- end card -->
              </div><!-- end col -->
            </div><!-- end row -->


          </div> <!-- container -->



@endsection
	