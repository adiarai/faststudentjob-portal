
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
  <title>Admin Panel</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />


    <link rel="shortcut icon" href="{{ asset('assets/images/favicon.ico')}}">


    <script src="{{ asset('assets/js/config.js')}}"></script>

    <!-- Vendor css -->
    <link href="{{ asset('assets/css/vendor.min.css')}}" rel="stylesheet" type="text/css" />

    <!-- App css -->
    <link href="{{ asset('assets/css/app.min.css')}}" rel="stylesheet" type="text/css" id="app-style" />

    <!-- Icons css -->
    <link href="{{ asset('assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
</head>

<body>

    <div class="auth-bg d-flex min-vh-100 justify-content-center align-items-center">
        <div class="row g-0 justify-content-center w-100 m-xxl-5 px-xxl-4 m-3">
            <div class="col-xl-4 col-lg-5 col-md-6">
                <div class="card overflow-hidden text-center h-100 p-xxl-4 p-3 mb-0">
                    <a href="index-2.html" class="auth-brand mb-4">
                        <!-- <img src="assets/images/logo-dark.png" alt="dark logo" height="26" class="logo-dark"> -->
                        <!-- <img src="assets/images/logo.png" alt="logo light" height="26" class="logo-light"> -->

                        <h2 style="color: black;font-weight: bold;">Fast Student Jobs</h2>
                    </a>

                    <h4 class="fw-semibold mb-2 fs-18">Log in to your admin account</h4>

                    <p class="text-muted mb-4">Enter your email address and password to access admin panel.</p>

                    <form autocomplete="OFF" action="login_submit" method="POST" class="text-start mb-3">
                        <div class="mb-3">
                            <label class="form-label" for="example-email">Email</label>
                            <input autocomplete="OFF" type="email" required id="example-email" name="login_email" class="form-control" placeholder="Enter your email">
                        </div>
                        @csrf

                        <div class="mb-3">
                            <label class="form-label" for="example-password">Password</label>
                            <input autocomplete="OFF" type="password" required name="login_password" id="example-password" class="form-control" placeholder="Enter your password">
                        </div>

                        
@if(session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
@endif



                        <div class="d-grid">
                            <button class="btn btn-primary fw-semibold" name="login_btn" type="submit">Login</button>
                        </div>
                    </form>


                    <p class="mt-auto mb-0">
                        <script>document.write(new Date().getFullYear())</script> © Fast Student Jobs - Created By <span class="fw-bold text-decoration-underline text-uppercase text-reset fs-12">Ali malik</span>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Vendor js -->
    <script src="{{ asset('assets/js/vendor.min.js')}}"></script>

    <!-- App js -->
    <script src="{{ asset('assets/js/app.js')}}"></script>

</body>

</html>