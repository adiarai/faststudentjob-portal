@include('admin.header')

<style type="text/css">
    th:before{
        display: none !important;
    }

    th:after{
        display: none !important;
    }
</style>
<body>
    <!-- Begin page -->
    <div class="wrapper">

@include('admin.sidebar')
@include('admin.navbar')


@yield('admin-content')


@include('admin.footer')

