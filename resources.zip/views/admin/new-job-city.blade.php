@extends('admin.layout')


@section('admin-content')

<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">


<style>
  #editor-container {
    height: 200px;
    background-color: #F0F5F7 !important;
  }
</style>

        <div class="page-content">

          <div class="page-container">


            <div class="page-title-head d-flex align-items-center gap-2">
              <div class="flex-grow-1">
                <h4 class="fs-16 text-uppercase fw-bold mb-0">Add New Job City</h4>
              </div>

            </div>




            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header border-bottom border-dashed d-flex align-items-center">
                    <h4 class="header-title">City Name</h4>
                  </div>

<div class="card-body">
@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif
          <form action="{{ route('job-city.store') }}" method="POST" enctype="multipart/form-data">
    @csrf

    <div class="form-group">
        <label>City name *</label>
        <input type="text" name="city_name" class="form-control @error('city') is-invalid @enderror" value="{{ old('type_name') }}" required>
        @error('city')
            <div class="invalid-feedback">{{ $message }}</div>
        @enderror
    </div>

    <div class="form-group mt-3">
        <label>Content *</label>
        <div id="editor-container"></div>
        <input type="hidden" name="content" id="hidden-input" required>
        @error('content')
            <div class="text-danger">{{ $message }}</div>
        @enderror
    </div>

    <div class="form-group mt-4">
        <button type="submit" class="btn btn-primary w-100">Save</button>
    </div>
</form>

                  </div> <!-- end card-body -->
                </div> <!-- end card -->
              </div><!-- end col -->
            </div><!-- end row -->


          </div> <!-- container -->


   

  <script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
  <script>
    var quill = new Quill('#editor-container', {
      theme: 'snow'
    });

    document.querySelector('form').onsubmit = function () {
      document.getElementById('hidden-input').value = quill.root.innerHTML;
    };
  </script>
@endsection
	