@extends('layout')

@section('main-content')
<style>
  body {
    counter-reset: liincreasremnt;
  }
  #count:before {
    counter-increment: liincreasremnt;
    content: counter(liincreasremnt)'. ';
    font-weight: 600;
    color: #00B850;
  }
  .icons {
    padding-top: 15px;
  }
  .arrow {
    display: none;
  }
  .project-main-content h2 {
    font-weight: 700;
    font-size: 2rem;
    border-bottom: 3px solid #00B850;
    padding-bottom: 8px;
    margin-bottom: 24px;
  }
  .project-main-content h4 {
    font-weight: 600;
    color: #00B850;
    margin-bottom: 12px;
  }
  .project-main-content p {
    font-size: 1rem;
    line-height: 1.6;
    color: #333;
  }
  .project-main-content ul {
    list-style: none;
    padding-left: 0;
  }
  .project-main-content ul li {
    padding-left: 32px;
    position: relative;
    margin-bottom: 12px;
    font-size: 1rem;
    color: #444;
  }
  .project-main-content ul li img {
    position: absolute;
    left: 0;
    top: 4px;
    width: 18px;
    height: 18px;
  }
  table.table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
    margin-top: 24px;
    box-shadow: 0 0 10px rgb(0 0 0 / 0.05);
  }
  table.table thead tr {
    background-color: #00B850;
    color: white;
    font-weight: 600;
  }
  table.table th,
  table.table td {
    padding: 12px 20px;
    border: 1px solid #dee2e6;
    text-align: left;
  }
  table.table tbody tr:nth-child(even) {
    background-color: #f8f9fa;
  }
  .commitment-box {
    background: #e9f2ff;
    border-left: 6px solid #00B850;
    padding: 20px 24px;
    margin-top: 40px;
    font-size: 1.1rem;
    color: #004085;
    border-radius: 4px;
  }
</style>

<!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
  <div class="container">
    <div class="row align-items-center">
      <div class="col-lg-7">
        <div class="inner-heading">
          <h1>Refund Policy</h1>
          <div class="space20"></div>
          <a href="#">Home <i class="fa-solid fa-angle-right"></i> Pricing & Policies <i class="fa-solid fa-angle-right"></i> <span>Refund Policy</span></a>
        </div>
      </div>
      <div class="col-lg-1 d-none d-lg-block"></div>
      <div class="col-lg-4">
        <div class="imges text-center">
          <img src="{{ asset('web-assets/img/all-images/hero/hero-img11.png') }}" alt="Refund Policy Image" style="max-width: 100%; height: auto;">
        </div>
      </div>
    </div>
  </div>
</div>
<!--===== HERO AREA ENDS =======-->

<div class="project-details-section sp1">
  <div class="container">
    <div class="row">
      <div class="col-lg-8 m-auto">
        <div class="project-main-content heading1">
          <h2>Pricing & Cancellation Policy</h2>
          <p>At Fast Student Jobs, our service is based on a performance-driven model. You only pay if we successfully arrange a job for you. Below is a clear overview of our pricing, cancellation, and payment terms:</p>

          <h4>1. Service Fee</h4>
          <ul>
            <li id="count"> A one-time fee of €250 is charged only after you get hired through us.</li>
            <li id="count"> There is no upfront payment required at any stage.</li>
          </ul>

          <h4>2. When You Pay</h4>
          <ul>
            <li id="count"> The €250 service fee must be paid within 7 days of either accepting a job arranged through us or deliberately rejecting a job offer we provide.</li>
          </ul>

          <h4>3. Cancellation Policy</h4>
          <ul>
            <li id="count"> Cancel within 2 days of registration: <strong>€0</strong> (No payment required).</li>
            <li id="count"> Cancel after 2 days of agreement: <strong>€50</strong> cancellation fee applies.</li>
          </ul>

          <h4>4. Late Payment Fees</h4>
          <ul>
            <li id="count"> Failing to pay any applicable fee within 7 days will result in a €25 late payment fee.</li>
            <li id="count"> Example: €50 cancellation unpaid = €75 total. €250 service fee unpaid = €275 total.</li>
          </ul>

          <h4>5. Job Rejection Policy</h4>
          <ul>
            <li id="count"> If you reject or ignore a job offer arranged by us, the €250 service fee still applies and must be paid within 7 days.</li>
          </ul>

          <h4>6. No Job – No Payment</h4>
          <ul>
            <li id="count"> If we are unable to get you hired within 2 months, you do not have to pay anything.</li>
          </ul>

          <h4>7. Refund Policy</h4>
          <ul>
            <li id="count"> Since no payment is taken in advance, refunds are not applicable.</li>
          </ul>

          <h4>Quick Summary</h4>
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Situation</th>
                <th>Fee</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Cancel within 2 days</td>
                <td>€0</td>
              </tr>
              <tr>
                <td>Cancel after 2 days</td>
                <td>€50</td>
              </tr>
              <tr>
                <td>Cancel after 2 days + unpaid</td>
                <td>€75</td>
              </tr>
              <tr>
                <td>Get hired or reject job</td>
                <td>€250</td>
              </tr>
              <tr>
                <td>Don't pay within 7 days</td>
                <td>€275</td>
              </tr>
              <tr>
                <td>No job within 2 months</td>
                <td>€0</td>
              </tr>
            </tbody>
          </table>

          <div class="commitment-box">
            <h3>Our Commitment</h3><br>
            <p>We’ve built this policy to ensure transparency, fairness, and peace of mind. No hidden charges, no surprises — just results. If you have any questions, our support team is here to help.</p>
          </div>
          
        </div>
      </div>
    </div>
  </div>
@endsection
