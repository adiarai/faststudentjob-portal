@extends('layout')

@section('main-content')
<style type="text/css">
    body {
        counter-reset: liincreasremnt;
    }

    #count:before {
        counter-increment: liincreasremnt;
        content: counter(liincreasremnt)'. ';
    }
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }
</style>

<!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url('{{ asset('web-assets/img/all-images/bg/hero-bg1.png') }}'); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Testimonials</h1>
                    <div class="space20"></div>
                    <a href="#">Home <i class="fa-solid fa-angle-right"></i> Pricing & Policies <i class="fa-solid fa-angle-right"></i> <span>Testimonials</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="web-assets/img/all-images/hero/hero-img11.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== HERO AREA ENDS =======-->

   <div class="testimonial-inner-area2 sp1">
      <div class="container">
         <div class="row">
           
          














<!-- Pakistan Reviews -->
<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
           <div class="icons">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                     </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“Found a job in just one week. Very grateful to Fast Student Jobs!”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Ahmed Khan</a>
            <div class="space10"></div>
            <p>Pakistan</p>
         </div>
      </div>
   </div>
</div>

<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“The process was smooth, and the team was always available on WhatsApp.”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Zainab Malik</a>
            <div class="space10"></div>
            <p>Pakistan</p>
         </div>
      </div>
   </div>
</div>

<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“Fast and affordable! I got my first student job while studying in Berlin.”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Ali Raza</a>
            <div class="space10"></div>
            <p>Pakistan</p>
         </div>
      </div>
   </div>
</div>

<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“Their refund policy is fair, and the whole process was transparent.”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Hina Aslam</a>
            <div class="space10"></div>
            <p>Pakistan</p>
         </div>
      </div>
   </div>
</div>

<!-- India Reviews -->
<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“They placed me in a kitchen job with flexible hours. Highly recommended!”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Rohan Verma</a>
            <div class="space10"></div>
            <p>India</p>
         </div>
      </div>
   </div>
</div>

<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“Very responsive customer support and smooth onboarding process.”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Sneha Joshi</a>
            <div class="space10"></div>
            <p>India</p>
         </div>
      </div>
   </div>
</div>

<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“Got a part-time delivery job while studying. Great for side income!”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Vikas Sharma</a>
            <div class="space10"></div>
            <p>India</p>
         </div>
      </div>
   </div>
</div>

<!-- Bangladesh Reviews -->
<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“Excellent platform. I didn’t expect to find a job so fast!”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Mehedi Hasan</a>
            <div class="space10"></div>
            <p>Bangladesh</p>
         </div>
      </div>
   </div>
</div>

<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“Quick onboarding and great follow-up. They really care!”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Nusrat Jahan</a>
            <div class="space10"></div>
            <p>Bangladesh</p>
         </div>
      </div>
   </div>
</div>

<!-- USA Reviews -->
<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“I’m an exchange student and Fast Student Jobs made my transition so easy.”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Emily Johnson</a>
            <div class="space10"></div>
            <p>USA</p>
         </div>
      </div>
   </div>
</div>

<div class="col-lg-4 col-md-6">
   <div class="testimonial-widget-box1">
      <div class="icons-area">
         <div class="icons">
            <!-- SVG here -->
             <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                           <path d="M18.75 13.748C21.2353 13.748 23.25 11.7333 23.25 9.24799C23.25 6.7627 21.2353 4.74799 18.75 4.74799C16.2647 4.74799 14.25 6.7627 14.25 9.24799C14.25 11.7333 16.2647 13.748 18.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M23.25 9.24799C23.25 12.0328 22.1438 14.7035 20.1746 16.6726C18.2055 18.6417 15.5348 19.748 12.75 19.748" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M6.75 13.748C9.23528 13.748 11.25 11.7333 11.25 9.24799C11.25 6.7627 9.23528 4.74799 6.75 4.74799C4.26472 4.74799 2.25 6.7627 2.25 9.24799C2.25 11.7333 4.26472 13.748 6.75 13.748Z" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                           <path d="M11.5 9C11.5 11.7848 10.3938 14.4555 8.42462 16.4246C6.45549 18.3938 3.78477 19.5 1 19.5" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
         </div>
         <ul>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li><i class="fa-solid fa-star"></i></li>
            <li>(5)</li>
         </ul>
      </div>
      <div class="space16"></div>
      <p class="pera">“Amazing support team! I got placed within 72 hours of signing up.”</p>
      <div class="space28"></div>
      <div class="images-area">
         <div class="text">
            <a href="#">Jake Miller</a>
            <div class="space10"></div>
            <p>USA</p>
         </div>
      </div>
   </div>
</div>
            
         </div>
      </div>
   </div>
   <!--===== TESTIMONIAL AREA ENDS =======-->
@endsection