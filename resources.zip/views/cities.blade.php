@extends('layout')
<!--===== MOBILE HEADER STARTS =======-->
@section('main-content')
<style>
  .icons{
    padding-top: 15px
  }
  .arrow{
    display: none
  }

  @media screen and (max-width:500px){
    .inner-header-area{
        display:none;
    }
  }
</style>

<!--===== HERO AREA STARTS =======-->
<div class="inner-header-area" style="background-image: url(web-assets/img/all-images/bg/hero-bg7.png); background-position: center; background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="inner-heading">
                    <h1>Our Job Cities</h1>
                    <div class="space20"></div>
                    <a href="index">Home <i class="fa-solid fa-angle-right"></i> <span>Our Job Cities</span></a>
                </div>
            </div>
            <div class="col-lg-1"></div>
            <div class="col-lg-4">
                <div class="imges">
                    <img src="web-assets/img/all-images/hero/hero-img11.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<!--===== HERO AREA ENDS =======-->

<!--===== TESTIMONIAL AREA STARTS =======-->
<div class="team-inner-area sp1">
    <div class="container">

    <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-5">
        <input id="search_city" class="form-control" placeholder="Enter city name" name="search_city">
    </div>

    <div class="row mt-5" id="city_cards">
        @foreach($all_city_data as $data)
        <div class="col-lg-4 col-md-6 mt-5 city-card">
            <div class="team-widget-boxarea">
                <div class="text-share-area">
                    <div class="text">
                        <a href="{{ url('jobs/' . $data->slug) }}">{{$data->city_name}}</a>
                        <div class="space14"></div>
                        <p>{{$data->slug}}</p>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>

<script>
document.getElementById('search_city').addEventListener('keyup', function() {
    let filter = this.value.toLowerCase();
    let cards = document.querySelectorAll('#city_cards .city-card');

    cards.forEach(function(card) {
        let cityName = card.querySelector('a').textContent.toLowerCase();
        if (cityName.includes(filter)) {
            card.style.display = "";
        } else {
            card.style.display = "none";
        }
    });
});
</script>


          
        </div>
    </div>
</div>
<!--===== TESTIMONIAL AREA ENDS =======-->


@endsection
